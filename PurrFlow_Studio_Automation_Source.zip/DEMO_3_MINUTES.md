# Three-minute demonstration script

Use the actual status on screen. Do not describe blocked jobs as published or test doubles as live results. Aim for about 330 spoken words and allow time for clicks.

## 0:00–0:25 — The problem

“A small creator can have a fun idea, but turning it into a consistent series across five social platforms creates repeated work: writing prompts, keeping a character consistent, editing captions, remembering schedules, and checking what actually published. PurrFlow Studio brings those tasks into one workspace. Our demonstration brand is Mochi Mischief, an original AI cat character.”

## 0:25–1:00 — Creator point of view

Show the dashboard. Enter one short original story and select destinations and a future time.

“I enter what happens in this episode and choose where and when I want it posted. The app saves a campaign and creates editable prompt templates and draft copy. Each destination has its own job, so a failure on one platform does not pretend the others succeeded.”

Expand the story prompts and platform copy.

## 1:00–1:35 — Creative output

Show the real Flow project and, only if completed, play the generated sample.

“This is Mochi's character reference. We generated this sample in Google Flow for ten included credits, attached the real MP4 here, and uploaded it to YouTube as Private with AI disclosure. The local app does not yet call Flow unattended; that connection is still a development dependency. The creative direction is one simple scene and a visual payoff.”

If generation is unfinished, say that it is pending and show its actual status.

## 1:35–2:15 — Operator point of view

Show the n8n successful execution and validated output, then dashboard job statuses.

“The n8n workflow actually ran: three prepared stories became fifteen destination drafts, and the publishing gate validated them. No posts were attempted in that validation run. The queue persists across a local restart, waits for the selected time, prevents a successful job from publishing twice, and holds an uncertain result for checking.”

## 2:15–2:45 — Evidence and limits

“Eight automated checks passed, including persistence, scheduling and failure recovery. These checks use test publishers. The real private YouTube upload was browser-assisted; the interface shows that automatic publishers are still unconnected. Our next milestone is a confirmed upload through the authorized n8n connection, followed by a real overnight run.”

## 2:45–3:00 — Close

“PurrFlow's goal is dependable creator automation: consistent stories, clear destination status and recovery when something goes wrong. The working prototype is ready to inspect, and its unfinished integrations are visible.”
