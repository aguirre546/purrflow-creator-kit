import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';

const execute = promisify(execFile);
const root = path.dirname(fileURLToPath(import.meta.url));
const destinations = ['facebook', 'instagram', 'youtube', 'x', 'tiktok'];

function httpsConfiguration(endpoint, token, account) {
  if (!endpoint) return 'missing';
  try {
    const url = new URL(endpoint);
    if (url.protocol !== 'https:' || url.username || url.password || !token || !account) return 'invalid';
    return 'configured_unverified';
  } catch { return 'invalid'; }
}

// Readiness is intentionally separate from configuration. This check never posts,
// refreshes credentials, tests arbitrary endpoints, or prints credential values.
export async function inspectReadiness({env = process.env, nodeVersion = process.versions.node,
  policy,
  run = execute} = {}) {
  policy ??= JSON.parse(await readFile(path.join(root, 'automation-policy.json'), 'utf8'));
  const checks = [];
  checks.push({id: 'node', state: Number(nodeVersion.split('.')[0]) >= 22 ? 'passed' : 'blocked',
    message: 'Node.js 22 or newer is required.'});
  const budgetSafe = policy?.generation?.existingCreditsOnly === true && policy?.generation?.allowNewCharges === false;
  checks.push({id: 'budget_policy', state: budgetSafe ? 'passed' : 'blocked',
    message: budgetSafe ? 'Existing credits only; new charges disabled.' : 'Restore the existing-credits-only policy before running.'});
  let mediaReady = false;
  if (env.PURRFLOW_FFMPEG) {
    try {
      const options = {timeout: 10000, maxBuffer: 1024 * 1024, windowsHide: true};
      const [encoders, filters] = await Promise.all([
        run(env.PURRFLOW_FFMPEG, ['-hide_banner', '-encoders'], options),
        run(env.PURRFLOW_FFMPEG, ['-hide_banner', '-filters'], options)
      ]);
      mediaReady = /\blibx264\b/.test(encoders.stdout) && /\bass\s/.test(filters.stdout);
    } catch { /* Do not expose executable paths or subprocess error output. */ }
  }
  checks.push({id: 'media', state: mediaReady ? 'passed' : 'blocked',
    message: mediaReady ? 'FFmpeg exposes libx264 and ASS captions; a real media test is still required.' : 'Configure a trusted FFmpeg with libx264 and ASS support.'});
  checks.push({id: 'generation', state: 'blocked', message: 'Unattended generation is not connected. A supported provider route and verified existing credits are required.'});
  checks.push({id: 'youtube_private_test', state: env.PURRFLOW_YOUTUBE_ACCESS_TOKEN ? 'configured_unverified' : 'missing',
    message: 'Use the private-upload check command to verify the exact channel; a token alone does not prove access.'});
  for (const destination of destinations) {
    const prefix = `PURRFLOW_${destination.toUpperCase()}`;
    checks.push({id: `${destination}_publisher`,
      state: httpsConfiguration(env[`${prefix}_WEBHOOK`], env.PURRFLOW_WEBHOOK_TOKEN, env[`${prefix}_ACCOUNT_ID`]),
      message: 'An authorized publisher, verified destination and live receipt are required. Configuration alone is not connection proof.'});
  }
  checks.push({id: 'alerts', state: httpsConfiguration(env.PURRFLOW_ALERT_WEBHOOK, env.PURRFLOW_ALERT_TOKEN, 'alert'),
    message: 'Configure an authorized exception destination and verify receipt of one test alert.'});
  checks.push({id: 'hosting', state: 'blocked', message: 'This worker binds to loopback. A secured persistent host and durable private media storage are not provisioned.'});
  checks.push({id: 'endurance', state: 'unverified', message: 'Overnight and seven-day operation have not been observed.'});
  return {schemaVersion: 1, mode: 'read_only_configuration_check', readyForUnattendedOperation: false,
    sendsNetworkRequests: false, checks};
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const result = await inspectReadiness();
  if (process.argv.includes('--json')) console.log(JSON.stringify(result, null, 2));
  else {
    console.log('PurrFlow readiness — configuration check only; no network requests.');
    for (const check of result.checks) console.log(`${check.id}: ${check.state} — ${check.message}`);
    console.log('Full unattended operation: not ready.');
  }
  process.exitCode = result.readyForUnattendedOperation ? 0 : 2;
}
