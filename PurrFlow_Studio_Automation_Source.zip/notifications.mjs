import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
export function createNotifier({data,endpoint,token,send=fetch}){
 if(endpoint){const u=new URL(endpoint);if(u.protocol!=='https:'||u.username||u.password||!token)throw Error('Alerts require HTTPS and a dedicated bearer token.');}
 const file=path.join(data,'alerts.json');let records=null;
 return async function notify(campaigns,now=Date.now()){
  if(!records){try{records=JSON.parse(await fs.readFile(file,'utf8'));}catch(e){if(e.code!=='ENOENT')throw e;records=[];}}
  for(const c of campaigns)for(const j of c.jobs){if(!['needs_attention','failed','schedule_hold'].includes(j.status))continue;
   const key=createHash('sha256').update([c.id,j.id,j.status,j.reason].join('|')).digest('hex');let alert=records.find(a=>a.key===key);
   if(!alert){alert={key,campaignId:c.id,platform:j.platform,status:j.status,createdAt:new Date(now).toISOString(),delivered:false,attempts:0};records.push(alert);}
   if(endpoint&&!alert.delivered&&alert.attempts<3&&now>=(alert.nextAttemptAt||0)){
    alert.attempts++;alert.nextAttemptAt=now+1800000;
    try{const response=await send(endpoint,{method:'POST',redirect:'error',signal:AbortSignal.timeout(15000),headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({event:'purrflow_exception',campaignId:c.id,platform:j.platform,status:j.status,message:'PurrFlow needs attention. Review the operator dashboard.'})});if(!response.ok)throw Error('Alert delivery failed');alert.delivered=true;}catch{alert.deliveryError='Notification delivery failed; check destination configuration.';}
   }
  }
  const tmp=file+'.tmp';await fs.writeFile(tmp,JSON.stringify(records.slice(-500),null,2));await fs.rename(tmp,file);return records;
 };
}
