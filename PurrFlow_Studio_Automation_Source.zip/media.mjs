import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
const run=promisify(execFile);
export async function inspectVideo(file,executable){
 if(!executable)return {passed:false,reason:'Media validator unavailable. Configure PURRFLOW_FFMPEG before automatic publishing.'};
 try{
  const {stderr}=await run(executable,['-hide_banner','-i',file,'-map','0:v:0','-an','-f','null','-'],{timeout:60000,maxBuffer:1024*1024,windowsHide:true});
  const duration=stderr.match(/Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)/);
  const dimensions=stderr.match(/Video:[^\r\n]*?\b(\d{2,5})x(\d{2,5})\b/);
  if(!duration||!dimensions)throw Error('Video metadata unavailable.');
  const seconds=+duration[1]*3600 + +duration[2]*60 + +duration[3],width=+dimensions[1],height=+dimensions[2];
  const passed=Math.abs(seconds-15)<=0.5&&width===720&&height===1280;
  return {passed,durationSeconds:seconds,width,height,decoded:true,checkedAt:new Date().toISOString(),reason:passed?null:'Expected a 15-second vertical 720 × 1280 video. This file needs attention.'};
 }catch{return {passed:false,reason:'Video could not be decoded and validated. Automatic publishing is blocked.'};}
}
