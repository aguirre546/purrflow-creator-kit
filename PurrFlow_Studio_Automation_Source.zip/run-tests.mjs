import {spawn} from 'node:child_process';
import {readdir} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';

// Tests must never inherit a configured production publisher, token, data path,
// or alert destination. FFmpeg is the only allowed PurrFlow test dependency.
const env = {...process.env};
for (const key of Object.keys(env)) if (/^PURRFLOW_/i.test(key) && key !== 'PURRFLOW_FFMPEG') delete env[key];
const root = fileURLToPath(new URL('./', import.meta.url));
const files = [];
for (const directory of ['test', 'n8n', 'integrations']) {
  for (const entry of await readdir(new URL(`./${directory}/`, import.meta.url), {withFileTypes: true})) {
    if (entry.isFile() && entry.name.endsWith('.test.mjs')) files.push(`${directory}/${entry.name}`);
  }
}
const child = spawn(process.execPath, ['--test', ...files.sort()], {cwd: root, env, stdio: 'inherit', windowsHide: true});
child.once('error', () => { console.error('The isolated test runner could not start.'); process.exitCode = 1; });
child.once('exit', code => { process.exitCode = code ?? 1; });
