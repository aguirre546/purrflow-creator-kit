import {randomUUID} from 'node:crypto';
export const platforms=['facebook','instagram','youtube','x','tiktok'];
export function platformDrafts(idea,selected=platforms){
 const story=idea.replace(/\s+/g,' ').trim();const short=story.length>140?story.slice(0,137)+'…':story;
 const copy={
 facebook:{title:'Mochi has a plan of his own',caption:`${story}\n\nWhat would your cat do? Tell us below. 🐾\nOriginal AI-generated cat story.`,hashtags:['MochiMischief','CatComedy']},
 instagram:{title:'A little Mochi mischief 🐾',caption:`One orange cat. Endless little adventures. 🐈\n\n${story}\n\nSend this to someone whose cat runs the house.\nFictional scene created with AI.`,hashtags:['MochiMischief','AICatStories','CatComedy','OrangeCat']},
 youtube:{title:('Mochi Mischief: '+story).slice(0,100),caption:`${story}\n\nMeet Mochi, our curious orange cat. Subscribe for the next little adventure.\nOriginal AI-generated fictional cat story.`,hashtags:['MochiMischief','CatShorts','AICatStories']},
 x:{title:'Mochi makes the rules',caption:`${short}\n\nMochi makes the rules. 🐈\nAI-generated fiction.`,hashtags:['MochiMischief']},
 tiktok:{title:'Wait for Mochi’s next move 👀',caption:`${short}\n\nWho else has a cat like this? 👀\nAI-generated cat story.`,hashtags:['MochiMischief','CatTok','OrangeCat']}
 };return Object.fromEntries(selected.map(p=>[p,copy[p]]));
}
export function campaign(input,now=Date.now()){
 const idea=String(input.idea||'').trim();
 if(idea.length<10||idea.length>1500)throw Error('Describe the story in 10–1500 characters.');
 const selected=[...new Set(input.platforms||[])];
 if(!selected.length||selected.some(p=>!platforms.includes(p)))throw Error('Choose valid publishing destinations.');
 const time=Date.parse(input.scheduledAt);if(!Number.isFinite(time)||time<now)throw Error('Choose a future posting time.');
 return {id:randomUUID(),idea,createdAt:new Date(now).toISOString(),scheduledAt:new Date(time).toISOString(),state:'needs_video',videoPath:null,drafts:platformDrafts(idea,selected),jobs:selected.map(platform=>({id:randomUUID(),platform,status:'blocked',reason:'Attach a finished video and connect a publisher.',attempts:0,nextAttemptAt:time,postId:null})),events:[{at:new Date(now).toISOString(),message:'Campaign created with distinct platform copy and one shared posting time. Draft copy needs editorial review.'}]};
}
export function prepare(c){
 const identity='Mochi: orange tabby, white muzzle and chest, green eyes, blue collar and round gold tag. Keep the approved reference character consistent.';
 return {generation:{provider:'Google Flow',model:'Omni 1.2 Flash',durationSeconds:15,resolution:'720p',outputCount:1,aspectRatio:'9:16',existingCreditsOnly:true},character:identity,hook:'Show the unexpected moment in the first two seconds.',imagePrompt:`Vertical 9:16 scene for this original story: ${c.idea}. ${identity} Clear composition, natural setting, no text or watermarks.`,motionPrompt:`Create exactly one 15-second 720p vertical 9:16 video with Omni 1.2 Flash. Animate this story in one simple continuous shot: ${c.idea}. ${identity} Believable movement, steady camera, no extra limbs or morphing. Natural ambience.`,note:'Template-assisted planning, not an AI generation result. Flow generation is not connected.'};
}
function updateState(c){
 c.state=c.jobs.length&&c.jobs.every(j=>j.status==='published')?'completed':c.jobs.some(j=>['failed','needs_attention'].includes(j.status))?'needs_attention':c.paused?'paused':c.jobs.some(j=>j.status==='schedule_hold')?'schedule_hold':c.jobs.every(j=>j.status==='blocked')?'blocked':c.videoPath?'ready':'needs_video';return c;
}
export function ready(c,adapters){for(const j of c.jobs){if(['published','processing','failed','needs_attention','schedule_hold','paused'].includes(j.status))continue;if(!c.videoPath){j.status='blocked';j.reason='No video attached.';}else if(!c.mediaQuality?.passed){j.status='blocked';j.reason=c.mediaQuality?.reason||'Video quality validation is required.';}else if(typeof adapters[j.platform]!=='function'){j.status='blocked';j.reason='Publisher is not connected.';}else if(j.status==='blocked'){j.status='queued';j.reason=null;}}return updateState(c);}
export async function tick(c,adapters,{now=Date.now(),persist=async()=>{},maxAttempts=3}={}){
 if(c.editing)return c;
 ready(c,adapters);
 if(c.state==='completed')return c;
 if(c.paused){c.state='paused';return c;}
 // An adapter coming online must never release an old blocked campaign.
 for(const j of c.jobs)if(['queued','blocked'].includes(j.status)&&j.attempts===0&&now-Date.parse(c.scheduledAt)>120000){j.status='schedule_hold';j.reason='Posting time expired. Choose a new future time before publishing.';}
 if(c.jobs.some(j=>j.status==='schedule_hold'))c.state='schedule_hold';
 const candidates=c.jobs.filter(job=>['queued','retry'].includes(job.status)&&Date.parse(c.scheduledAt)<=now&&job.nextAttemptAt<=now);
 const due=[];
 // Validate stored and generated copy before an adapter can dispatch anything.
 for(const job of candidates){try{validateDrafts(c.drafts,[job.platform]);due.push(job);}catch(err){job.status='failed';job.reason=errorMessage(err);c.events.push({at:new Date(now).toISOString(),message:`${job.platform}: failed — ${job.reason}`});}}
 for(const job of due){job.status='processing';job.attempts++;}
 if(candidates.length)await persist();
 await Promise.all(due.map(async job=>{
  try{
   const result=await adapters[job.platform]({campaign:c,job,idempotencyKey:job.id});
   if(typeof result?.postId!=='string'||!result.postId.trim())throw Object.assign(Error('Publisher did not return a confirmed post ID.'),{uncertain:true});
   job.status='published';job.postId=result.postId;job.url=result.url||null;job.reason=null;
  }catch(err){job.reason=errorMessage(err);const beforeDispatch=err?.dispatched===false&&err?.uncertain!==true;job.status=beforeDispatch?(err?.retryable===true&&job.attempts<maxAttempts?'retry':'failed'):'needs_attention';if(job.status==='retry')job.nextAttemptAt=now+60000*2**(job.attempts-1);}
  c.events.push({at:new Date(now).toISOString(),message:`${job.platform}: ${job.status}${job.reason?' — '+job.reason:''}`});await persist();
 }));
 updateState(c);await persist();return c;
}
function errorMessage(err){return (typeof err?.message==='string'&&err.message.trim()?err.message:typeof err==='string'&&err.trim()?err:'Publisher failed without a usable error message. Verify destination before retrying.').slice(0,500);}
export function recover(c){delete c.editing;for(const j of c.jobs)if(j.status==='processing'){j.status='needs_attention';j.reason='Interrupted during publishing. Verify destination before retrying to avoid duplicates.';}return updateState(c);}

export const notSentAcknowledgment='I VERIFIED THIS POST WAS NOT SENT';
export function reconcileJob(c,jobId,decision,{now=Date.now(),expectedAccountId}={}){
 if(c.editing||c.jobs.some(j=>j.status==='processing'))throw Error('Publishing or editing is in progress.');
 const job=c.jobs.find(j=>j.id===jobId);if(!job)throw Error('Unknown publishing job.');
 if(!['failed','needs_attention'].includes(job.status))throw Error('Only failed or uncertain publishing jobs can be reconciled.');
 const at=new Date(now).toISOString();let record;
 if(decision?.action==='published'){
  if(typeof expectedAccountId!=='string'||!expectedAccountId.trim())throw Error('Configure the expected destination account before confirming a published post.');
  const receipt=validateReceipt(decision.receipt,{platform:job.platform,accountId:expectedAccountId});
  record={at,action:'published',source:'operator',providerVerified:false,previousStatus:job.status,receipt:{platform:receipt.platform,accountId:receipt.accountId,status:receipt.status,visibility:receipt.visibility,postId:receipt.postId,url:receipt.url}};
  job.status='published';job.postId=receipt.postId;job.url=receipt.url;job.reason=null;
 }else if(decision?.action==='confirmed_not_sent'){
  if(decision.acknowledgment!==notSentAcknowledgment)throw Error('Type the exact acknowledgment after verifying the post was not sent.');
  record={at,action:'confirmed_not_sent',source:'operator',providerVerified:false,previousStatus:job.status,acknowledgment:notSentAcknowledgment};
  job.status='paused';job.reason='Operator confirmed no post was sent. Choose a new future schedule before retrying.';c.paused=true;
 }else throw Error('Choose published or confirmed_not_sent.');
 (job.reconciliations??=[]).push(record);
 c.events.push({at,message:`${job.platform}: operator confirmed ${record.action==='published'?'a public post':'no post was sent; campaign paused'}. Provider API verification was not performed.`});
 return updateState(c);
}

export function reschedule(c,scheduledAt,now=Date.now()){
 const time=Date.parse(scheduledAt);
 if(!Number.isFinite(time)||time<now+60000)throw Error('Choose a posting time at least one minute in the future.');
 if(c.jobs.some(j=>['processing','needs_attention'].includes(j.status)))throw Error('Reconcile uncertain delivery before rescheduling.');
 if(c.jobs.some(j=>j.status==='failed'))throw Error('Resolve failed jobs before rescheduling.');
 c.scheduledAt=new Date(time).toISOString();c.paused=false;
 for(const j of c.jobs)if(j.status!=='published'){j.status='blocked';j.reason='Rechecking media and connection.';j.nextAttemptAt=time;}
 c.events.push({at:new Date(now).toISOString(),message:'Unpublished destinations rescheduled explicitly.'});return c;
}
export function validateDrafts(drafts,selected){
 const limits={facebook:5000,instagram:2200,youtube:5000,x:240,tiktok:2200};const result={};
 if(!drafts||typeof drafts!=='object'||Array.isArray(drafts))throw Error('Platform drafts are required.');
 for(const p of selected){if(!platforms.includes(p))throw Error('Choose valid publishing destinations.');const d=drafts[p];if(!d||typeof d.title!=='string'||!d.title.trim()||typeof d.caption!=='string'||!d.caption.trim())throw Error('Title and caption are required for '+p);
 if(d.hashtags!==undefined&&(!Array.isArray(d.hashtags)||d.hashtags.some(t=>typeof t!=='string')))throw Error('Hashtags must be a list of plain text tags.');
 const tags=d.hashtags||[];
 if(tags.length>10||tags.some(t=>!/^\p{L}[\p{L}\p{N}_]{0,49}$/u.test(t)))throw Error('Use up to ten plain hashtags without spaces.');
 const combined=d.caption+' '+tags.map(t=>'#'+t).join(' ');
 // Conservative local limits; destination APIs remain authoritative (including X weighted length).
 if([...combined].length>limits[p]||[...d.title].length>100)throw Error('Shorten '+p+' copy to fit its publishing limit.');
 result[p]={title:d.title,caption:d.caption,hashtags:tags};}
 return result;
}
export function validateReceipt(result,expected){
 const nonempty=value=>typeof value==='string'&&Boolean(value.trim());
 if(!result||!expected||!platforms.includes(expected.platform)||result.platform!==expected.platform||!nonempty(expected.accountId)||!nonempty(result.accountId)||result.accountId!==expected.accountId||result.status!=='published'||result.visibility!=='public'||!nonempty(result.postId)||!publicationUrlMatches(result.url,expected.platform))throw Object.assign(Error('Publication receipt needs reconciliation: account, visibility or processing is unverified.'),{uncertain:true});
 return result;
}
function publicationUrlMatches(value,platform){
 if(typeof value!=='string'||!/^https:\/\/[^/\s?#]+\//.test(value)||/[\s\\]/u.test(value))return false;
 try{const url=new URL(value);if(url.protocol!=='https:'||url.username||url.password||url.port)return false;
  const domains={facebook:['facebook.com','fb.watch'],instagram:['instagram.com'],youtube:['youtube.com','youtu.be'],x:['x.com','twitter.com'],tiktok:['tiktok.com']};
  if(!domains[platform]?.some(domain=>url.hostname===domain||url.hostname.endsWith('.'+domain)))return false;
  return url.pathname!=='/'&&url.pathname.length>1;
 }catch{return false;}
}
