import {randomUUID} from 'node:crypto';
export const platforms=['facebook','instagram','youtube','x','tiktok'];
export function platformDrafts(idea,selected=platforms){
 const story=idea.replace(/\s+/g,' ').trim();const short=story.length>140?story.slice(0,137)+'…':story;
 const copy={
 facebook:{title:'Mochi has a plan of his own',caption:`${story}\n\nWhat would your cat do? Tell us below. 🐾\nOriginal AI-generated cat story.`,hashtags:['MochiMischief','CatComedy']},
 instagram:{title:'A little Mochi mischief 🐾',caption:`One orange cat. Endless little adventures. 🐈\n\n${story}\n\nSend this to someone whose cat runs the house.\nFictional scene created with AI.`,hashtags:['MochiMischief','AICatStories','CatComedy','OrangeCat']},
 youtube:{title:('Mochi Mischief: '+story).slice(0,100),caption:`${story}\n\nMeet Mochi, our curious orange cat. Subscribe for the next little adventure.\nOriginal AI-generated fictional cat story.`,hashtags:['MochiMischief','CatShorts','AICatStories']},
 x:{title:'Mochi makes the rules',caption:`${short}\n\nMochi makes the rules. 🐈\nAI-generated fiction.`,hashtags:['MochiMischief']},
 tiktok:{title:'Wait for Mochi’s next move 👀',caption:`${short}\n\nWho else has a cat like this? 👀\nAI-generated cat story.`,hashtags:['MochiMischief','CatTok','OrangeCat']}
 };return Object.fromEntries(selected.map(p=>[p,copy[p]]));
}
export function campaign(input,now=Date.now()){
 const idea=String(input.idea||'').trim();
 if(idea.length<10||idea.length>1500)throw Error('Describe the story in 10–1500 characters.');
 const selected=[...new Set(input.platforms||[])];
 if(!selected.length||selected.some(p=>!platforms.includes(p)))throw Error('Choose valid publishing destinations.');
 const time=Date.parse(input.scheduledAt);if(!Number.isFinite(time)||time<now)throw Error('Choose a future posting time.');
 return {id:randomUUID(),idea,createdAt:new Date(now).toISOString(),scheduledAt:new Date(time).toISOString(),state:'needs_video',videoPath:null,drafts:platformDrafts(idea,selected),jobs:selected.map(platform=>({id:randomUUID(),platform,status:'blocked',reason:'Attach a finished video and connect a publisher.',attempts:0,nextAttemptAt:time,postId:null})),events:[{at:new Date(now).toISOString(),message:'Campaign created with distinct platform copy and one shared posting time. Draft copy needs editorial review.'}]};
}
export function prepare(c){
 const identity='Mochi: orange tabby, white muzzle and chest, green eyes, blue collar and round gold tag. Keep the approved reference character consistent.';
 return {generation:{provider:'Google Flow',model:'Omni 1.2 Flash',durationSeconds:15,resolution:'720p',outputCount:1,aspectRatio:'9:16',existingCreditsOnly:true},character:identity,hook:'Show the unexpected moment in the first two seconds.',imagePrompt:`Vertical 9:16 scene for this original story: ${c.idea}. ${identity} Clear composition, natural setting, no text or watermarks.`,motionPrompt:`Create exactly one 15-second 720p vertical 9:16 video with Omni 1.2 Flash. Animate this story in one simple continuous shot: ${c.idea}. ${identity} Believable movement, steady camera, no extra limbs or morphing. Natural ambience.`,note:'Template-assisted planning, not an AI generation result. Flow generation is not connected.'};
}
export function ready(c,adapters){for(const j of c.jobs){if(['published','processing','failed','needs_attention','schedule_hold','paused'].includes(j.status))continue;if(!c.videoPath){j.status='blocked';j.reason='No video attached.';}else if(!c.mediaQuality?.passed){j.status='blocked';j.reason=c.mediaQuality?.reason||'Video quality validation is required.';}else if(!adapters[j.platform]){j.status='blocked';j.reason='Publisher is not connected.';}else if(j.status==='blocked'){j.status='queued';j.reason=null;}}c.state=c.jobs.every(j=>j.status==='published')?'completed':c.jobs.some(j=>['failed','needs_attention'].includes(j.status))?'needs_attention':c.jobs.every(j=>j.status==='blocked')?'blocked':c.videoPath?'ready':'needs_video';return c;}
export async function tick(c,adapters,{now=Date.now(),persist=async()=>{},maxAttempts=3}={}){
 if(c.editing)return c;
 ready(c,adapters);
 if(c.paused){c.state='paused';return c;}
 // An adapter coming online must never release an old blocked campaign.
 for(const j of c.jobs)if(['queued','blocked'].includes(j.status)&&j.attempts===0&&now-Date.parse(c.scheduledAt)>120000){j.status='schedule_hold';j.reason='Posting time expired. Choose a new future time before publishing.';}
 if(c.jobs.some(j=>j.status==='schedule_hold'))c.state='schedule_hold';
 const due=c.jobs.filter(job=>['queued','retry'].includes(job.status)&&Date.parse(c.scheduledAt)<=now&&job.nextAttemptAt<=now);
 for(const job of due){job.status='processing';job.attempts++;}
 if(due.length)await persist();
 await Promise.all(due.map(async job=>{
  try{
   const result=await adapters[job.platform]({campaign:c,job,idempotencyKey:job.id});
   if(!result?.postId)throw Object.assign(Error('Publisher did not return a confirmed post ID.'),{uncertain:true});
   job.status='published';job.postId=String(result.postId);job.url=result.url||null;job.reason=null;
  }catch(err){job.reason=String(err.message).slice(0,500);job.status=err.uncertain?'needs_attention':job.attempts>=maxAttempts?'failed':'retry';job.nextAttemptAt=now+60000*2**(job.attempts-1);}
  c.events.push({at:new Date(now).toISOString(),message:`${job.platform}: ${job.status}${job.reason?' — '+job.reason:''}`});await persist();
 }));
 c.state=c.jobs.every(j=>j.status==='published')?'completed':c.jobs.some(j=>['failed','needs_attention'].includes(j.status))?'needs_attention':c.state;await persist();return c;
}
export function recover(c){delete c.editing;for(const j of c.jobs)if(j.status==='processing'){j.status='needs_attention';j.reason='Interrupted during publishing. Verify destination before retrying to avoid duplicates.';}return c;}

export function reschedule(c,scheduledAt,now=Date.now()){
 const time=Date.parse(scheduledAt);
 if(!Number.isFinite(time)||time<now+60000)throw Error('Choose a posting time at least one minute in the future.');
 if(c.jobs.some(j=>['processing','needs_attention'].includes(j.status)))throw Error('Reconcile uncertain delivery before rescheduling.');
 if(c.jobs.some(j=>j.status==='failed'))throw Error('Resolve failed jobs before rescheduling.');
 c.scheduledAt=new Date(time).toISOString();c.paused=false;
 for(const j of c.jobs)if(j.status!=='published'){j.status='blocked';j.reason='Rechecking media and connection.';j.nextAttemptAt=time;}
 c.events.push({at:new Date(now).toISOString(),message:'Unpublished destinations rescheduled explicitly.'});return c;
}
export function validateDrafts(drafts,selected){
 const limits={facebook:5000,instagram:2200,youtube:5000,x:240,tiktok:2200};const result={};
 for(const p of selected){const d=drafts[p];if(!d||typeof d.title!=='string'||!d.title.trim()||typeof d.caption!=='string'||!d.caption.trim())throw Error('Title and caption are required for '+p);
 const tags=Array.isArray(d.hashtags)?d.hashtags.map(String):[];
 if(tags.length>10||tags.some(t=>!/^\p{L}[\p{L}\p{N}_]{0,49}$/u.test(t)))throw Error('Use up to ten plain hashtags without spaces.');
 const combined=d.caption+' '+tags.map(t=>'#'+t).join(' ');
 // Conservative local limits; destination APIs remain authoritative (including X weighted length).
 if([...combined].length>limits[p]||[...d.title].length>100)throw Error('Shorten '+p+' copy to fit its publishing limit.');
 result[p]={title:d.title,caption:d.caption,hashtags:tags};}
 return result;
}
export function validateReceipt(result,expected){
 if(!result||result.platform!==expected.platform||String(result.accountId)!==String(expected.accountId)||result.status!=='published'||result.visibility!=='public'||!result.postId||!/^https:\/\//.test(result.url||''))throw Object.assign(Error('Publication receipt needs reconciliation: account, visibility or processing is unverified.'),{uncertain:true});
 return result;
}
