import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {createPrivateUploader, EXPECTED_CHANNEL, MAX_BYTES, privateMetadata, safeError, validateSessionUrl} from './youtube-private.mjs';

const ACCESS = 'TEST_ACCESS_TOKEN_DO_NOT_LOG';
const SESSION = 'https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&upload_id=PRIVATE_SESSION';
const VIDEO = 'AbCdEfGhI12';
const json = (value, status = 200) => new Response(JSON.stringify(value), {status, headers: {'Content-Type': 'application/json'}});
const channel = () => json({items: [{id: EXPECTED_CHANNEL}]});
const video = (patch = {}) => ({id: VIDEO, snippet: {channelId: EXPECTED_CHANNEL}, status: {
  privacyStatus: 'private', containsSyntheticMedia: true, selfDeclaredMadeForKids: false, uploadStatus: 'uploaded'},
  processingDetails: {processingStatus: 'processing'}, ...patch});

async function fixture(t, handler) {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'purr-youtube-test-'));
  t.after(() => fs.rm(root, {recursive: true, force: true}));
  const bytes = Buffer.alloc(24); bytes.writeUInt32BE(24, 0); bytes.write('ftypisom', 4);
  const file = path.join(root, 'mochi.mp4'); await fs.writeFile(file, bytes);
  const stateDir = path.join(root, 'state');
  const calls = [];
  const fetchImpl = async (url, options) => { calls.push({url, options}); return handler(url, options, calls.length); };
  const uploader = createPrivateUploader({stateDir, fetchImpl, env: {PURRFLOW_YOUTUBE_ACCESS_TOKEN: ACCESS}});
  return {uploader, root, stateDir, file, bytes, calls, options: {file, title: 'Mochi private test', madeForKids: false, confirmPrivate: true}};
}
async function journal(stateDir) {
  const name = (await fs.readdir(stateDir)).find(name => name.endsWith('.jsonl'));
  const source = await fs.readFile(path.join(stateDir, name), 'utf8');
  return {name, source, entries: source.trim().split('\n').map(JSON.parse), last: JSON.parse(source.trim().split('\n').at(-1)).state};
}
const happy = async (url, options) => {
  if (url.includes('/channels?')) return channel();
  if (options.method === 'POST') return new Response(null, {status: 200, headers: {location: SESSION}});
  if (options.method === 'PUT') return json(video(), 201);
  return json({items: [video()]});
};

test('confirmation and an explicit audience decision are required before local state or network', async t => {
  const f = await fixture(t, happy);
  await assert.rejects(f.uploader.upload({...f.options, confirmPrivate: false}), {code: 'CONFIRMATION_REQUIRED'});
  await assert.rejects(f.uploader.upload({...f.options, madeForKids: undefined}), {code: 'KIDS_DECLARATION_REQUIRED'});
  await assert.rejects(f.uploader.upload({...f.options, madeForKids: 'false'}), {code: 'KIDS_DECLARATION_REQUIRED'});
  assert.equal(f.calls.length, 0);
  await assert.rejects(fs.stat(f.stateDir), {code: 'ENOENT'});
});

test('private metadata has no public setting or implicit audience default', () => {
  assert.deepEqual(privateMetadata({title: 'Mochi', madeForKids: true}).status, {
    privacyStatus: 'private', containsSyntheticMedia: true, selfDeclaredMadeForKids: true});
  assert.throws(() => privateMetadata({title: '<bad>', madeForKids: false}), {code: 'INVALID_METADATA'});
  assert.throws(() => privateMetadata({title: 'Mochi', description: '😀'.repeat(2000), madeForKids: false}), {code: 'INVALID_METADATA'});
});

test('wrong extension, header, box size, directory and oversize file stop before network', async t => {
  const f = await fixture(t, happy);
  for (const [name, content] of [['bad.webm', f.bytes], ['header.mp4', Buffer.from('invalid media header')], ['box.mp4', Buffer.from('0000ftypisom00000000')]]) {
    const location = path.join(f.root, name); await fs.writeFile(location, content);
    await assert.rejects(f.uploader.upload({...f.options, file: location}), {code: 'INVALID_MEDIA'});
  }
  const large = path.join(f.root, 'large.mp4'); const handle = await fs.open(large, 'w'); await handle.truncate(MAX_BYTES + 1); await handle.close();
  await assert.rejects(f.uploader.upload({...f.options, file: large}), {code: 'INVALID_MEDIA'});
  const directory = path.join(f.root, 'dir.mp4'); await fs.mkdir(directory);
  await assert.rejects(f.uploader.upload({...f.options, file: directory}), {code: 'INVALID_MEDIA'});
  assert.equal(f.calls.length, 0);
});

test('identity requires exactly one intended channel and no next page', async t => {
  for (const body of [{items: []}, {items: [{id: 'wrong'}]}, {items: [{id: EXPECTED_CHANNEL}, {id: 'other'}]}, {items: [{id: EXPECTED_CHANNEL}], nextPageToken: 'more'}]) {
    const f = await fixture(t, () => json(body));
    await assert.rejects(f.uploader.upload(f.options), {code: 'IDENTITY_MISMATCH'});
    assert.equal(f.calls.length, 1); assert.equal(f.calls[0].options.method, 'GET');
    assert.equal((await journal(f.stateDir)).last.phase, 'attention_required');
  }
});

test('intent and private session are durably journaled before channel check and media PUT', async t => {
  let f;
  f = await fixture(t, async (url, options) => {
    const {last} = await journal(f.stateDir);
    if (url.includes('/channels?')) assert.equal(last.phase, 'intent_saved');
    if (options.method === 'POST') {
      assert.equal(last.phase, 'initiation_pending');
      const metadata = JSON.parse(options.body);
      assert.equal(metadata.status.privacyStatus, 'private');
      assert.equal(metadata.status.containsSyntheticMedia, true);
      assert.equal(metadata.status.selfDeclaredMadeForKids, false);
      assert.match(url, /notifySubscribers=false/);
    }
    if (options.method === 'PUT') { assert.equal(last.phase, 'bytes_pending'); assert.equal(last.sessionUrl, SESSION); }
    assert.equal(options.redirect, 'manual');
    assert.equal(options.headers.Authorization, `Bearer ${ACCESS}`);
    return happy(url, options);
  });
  const result = await f.uploader.upload(f.options);
  assert.equal(result.privateVerified, true); assert.equal(result.uploadAccepted, true);
  assert.equal(result.processingComplete, false); assert.equal(result.processingStatus, 'processing');
  assert.equal(f.calls.length, 4);
  assert.ok(!JSON.stringify(result).includes(ACCESS)); assert.ok(!JSON.stringify(result).includes(SESSION));
  assert.ok(!(await journal(f.stateDir)).source.includes(ACCESS));
});

test('accepted upload and fully processed video are distinct receipt states', async t => {
  const f = await fixture(t, (url, options) => url.includes('/youtube/v3/videos?') && options.method === 'GET'
    ? json({items: [video({status: {...video().status, uploadStatus: 'processed'}, processingDetails: {processingStatus: 'succeeded'}})]}) : happy(url, options));
  const result = await f.uploader.upload(f.options);
  assert.equal(result.processingComplete, true); assert.equal(result.privateVerified, true);
});

test('same file and metadata cannot initiate again, including from a second uploader instance', async t => {
  const f = await fixture(t, happy);
  const first = await f.uploader.upload(f.options);
  const second = createPrivateUploader({stateDir: f.stateDir, fetchImpl: () => { throw Error('Unexpected request'); }, env: {PURRFLOW_YOUTUBE_ACCESS_TOKEN: ACCESS}});
  const result = await second.upload(f.options);
  assert.equal(first.jobId, result.jobId); assert.equal(result.duplicatePrevented, true); assert.equal(result.uploadAttempted, false);
  assert.equal(f.calls.length, 4);
});

test('concurrent calls to the same job use one lock and one session', async t => {
  let release; const gate = new Promise(resolve => { release = resolve; });
  let entered; const active = new Promise(resolve => { entered = resolve; });
  const f = await fixture(t, async (url, options) => { if (url.includes('/channels?')) { entered(); await gate; } return happy(url, options); });
  const first = f.uploader.upload(f.options); await active;
  await assert.rejects(f.uploader.upload(f.options), {code: 'LOCKED'});
  release(); await first;
  assert.equal(f.calls.filter(call => call.options.method === 'POST').length, 1);
});

test('exact session host, path, authority and upload id are enforced', () => {
  for (const url of [
    'http://www.googleapis.com/upload/youtube/v3/videos?upload_id=x',
    'https://www.googleapis.com.evil.test/upload/youtube/v3/videos?upload_id=x',
    'https://user:secret@www.googleapis.com/upload/youtube/v3/videos?upload_id=x',
    'https://www.googleapis.com:444/upload/youtube/v3/videos?upload_id=x',
    'https://www.googleapis.com/upload/youtube/v3/videos/../videos?upload_id=x',
    'https://www.googleapis.com/upload/youtube/v3/videos?upload_id=x#fragment',
    'https://www.googleapis.com/upload/youtube/v3/videos?upload_id=x&upload_id=y',
    'https://www.googleapis.com/upload/youtube/v3/videos?other=x',
  ]) assert.throws(() => validateSessionUrl(url), {code: 'INVALID_SESSION'});
  assert.equal(validateSessionUrl(SESSION), SESSION);
});

test('untrusted initiation session cannot receive media or bearer credentials', async t => {
  const f = await fixture(t, (url, options) => options.method === 'POST'
    ? new Response(null, {status: 200, headers: {location: 'https://evil.test/?secret=x'}}) : happy(url, options));
  await assert.rejects(f.uploader.upload(f.options), {code: 'INVALID_SESSION'});
  assert.equal(f.calls.length, 2); assert.ok(f.calls.every(call => call.url.startsWith('https://www.googleapis.com/')));
});

test('redirects are refused with no automatic retry and sanitized output', async t => {
  const f = await fixture(t, () => new Response(null, {status: 302, headers: {location: 'https://evil.test/?secret=x'}}));
  let caught; try { await f.uploader.upload(f.options); } catch (error) { caught = error; }
  assert.equal(caught.code, 'REDIRECT_BLOCKED'); assert.equal(f.calls.length, 1);
  assert.ok(!JSON.stringify(safeError(caught)).includes('evil'));
  assert.equal(f.calls[0].options.redirect, 'manual');
});

test('401 and quota error bodies are not logged, persisted or retried', async t => {
  for (const status of [401, 403, 429, 503]) {
    const sensitive = `RAW_SERVER_BODY ${ACCESS} ${SESSION}`;
    const f = await fixture(t, () => new Response(sensitive, {status}));
    let caught; try { await f.uploader.upload(f.options); } catch (error) { caught = error; }
    assert.equal(caught.code, 'API_REJECTED'); assert.equal(f.calls.length, 1);
    assert.ok(!JSON.stringify(safeError(caught)).includes('RAW_SERVER_BODY'));
    const {source} = await journal(f.stateDir);
    assert.ok(!source.includes('RAW_SERVER_BODY')); assert.ok(!source.includes(ACCESS));
  }
});

test('successful HTTP response with malformed receipt stays blocked and keeps its private session', async t => {
  const f = await fixture(t, (url, options) => options.method === 'PUT' ? json({unexpected: true}, 201) : happy(url, options));
  let caught; try { await f.uploader.upload(f.options); } catch (error) { caught = error; }
  assert.equal(caught.code, 'INVALID_RESPONSE');
  const {last} = await journal(f.stateDir);
  assert.equal(last.sessionUrl, SESSION); assert.equal(last.uploadAccepted, false);
  assert.equal((await f.uploader.upload(f.options)).duplicatePrevented, true);
  assert.equal(f.calls.length, 3);
});

test('ambiguous initiation leaves a durable blocked intent and never creates another session', async t => {
  const f = await fixture(t, (url, options) => { if (options.method === 'POST') throw Error(`Bearer ${ACCESS} ${SESSION}`); return channel(); });
  let caught; try { await f.uploader.upload(f.options); } catch (error) { caught = error; }
  assert.equal(caught.code, 'NETWORK_UNCERTAIN'); assert.equal(f.calls.length, 2);
  assert.ok(!JSON.stringify(safeError(caught)).includes(ACCESS)); assert.ok(!JSON.stringify(safeError(caught)).includes(SESSION));
  const duplicate = await f.uploader.upload(f.options); assert.equal(duplicate.duplicatePrevented, true);
  const result = await f.uploader.reconcile(caught.jobId);
  assert.equal(result.nextAction, 'manual_reconciliation'); assert.equal(f.calls.length, 2);
});

test('lost media response reconciles using zero bytes and verifies the existing video', async t => {
  const f = await fixture(t, (url, options) => {
    if (options.method === 'PUT' && options.body.length > 0) throw Error('Socket closed with ambiguous result');
    return happy(url, options);
  });
  let caught; try { await f.uploader.upload(f.options); } catch (error) { caught = error; }
  assert.equal(caught.code, 'NETWORK_UNCERTAIN');
  const result = await f.uploader.reconcile(caught.jobId);
  assert.equal(result.privateVerified, true); assert.equal(result.videoId, VIDEO);
  assert.equal(f.calls.filter(call => call.options.method === 'POST').length, 1);
  const puts = f.calls.filter(call => call.options.method === 'PUT');
  assert.equal(puts.length, 2); assert.equal(puts[1].options.body.length, 0);
  assert.equal(puts[1].options.headers['Content-Range'], `bytes */${f.bytes.length}`);
});

test('incomplete session reconciliation reports only byte count and never resends bytes', async t => {
  const f = await fixture(t, (url, options) => options.method === 'PUT'
    ? new Response(null, {status: 308, headers: {range: 'bytes=0-9'}}) : happy(url, options));
  let caught; try { await f.uploader.upload(f.options); } catch (error) { caught = error; }
  const result = await f.uploader.reconcile(caught.jobId);
  assert.equal(result.phase, 'incomplete'); assert.equal(result.receivedBytes, 10); assert.equal(result.privateVerified, false);
  assert.equal(f.calls.filter(call => call.options.method === 'POST').length, 1);
  assert.equal(f.calls.at(-1).options.body.length, 0);
});

test('expired session does not clear deduplication or create a new session', async t => {
  const f = await fixture(t, (url, options) => options.method === 'PUT'
    ? new Response(null, {status: 404}) : happy(url, options));
  let caught; try { await f.uploader.upload(f.options); } catch (error) { caught = error; }
  const result = await f.uploader.reconcile(caught.jobId);
  assert.equal(result.phase, 'session_unavailable'); assert.equal(result.nextAction, 'manual_reconciliation');
  assert.equal((await f.uploader.upload(f.options)).duplicatePrevented, true);
  assert.equal(f.calls.filter(call => call.options.method === 'POST').length, 1);
});

test('wrong private receipt settings never count as verified, while accepted id remains for recovery', async t => {
  for (const incorrect of [
    {snippet: {channelId: 'wrong'}}, {status: {...video().status, privacyStatus: 'public'}},
    {status: {...video().status, containsSyntheticMedia: false}}, {status: {...video().status, selfDeclaredMadeForKids: true}},
  ]) {
    const f = await fixture(t, (url, options) => url.includes('/youtube/v3/videos?') && options.method === 'GET'
      ? json({items: [video(incorrect)]}) : happy(url, options));
    await assert.rejects(f.uploader.upload(f.options), {code: 'RECEIPT_UNVERIFIED'});
    const {last} = await journal(f.stateDir);
    assert.equal(last.uploadAccepted, true); assert.equal(last.videoId, VIDEO); assert.equal(last.privateVerified, false);
  }
});

test('reconciliation with saved video id uses GET only after checking the channel', async t => {
  const f = await fixture(t, happy); const first = await f.uploader.upload(f.options);
  const before = f.calls.length; const result = await f.uploader.reconcile(first.jobId);
  assert.equal(result.privateVerified, true); assert.equal(f.calls.length, before + 2);
  assert.ok(f.calls.slice(before).every(call => call.options.method === 'GET'));
});

test('truncated and corrupted journals fail closed before network', async t => {
  const f = await fixture(t, happy); const first = await f.uploader.upload(f.options);
  const info = await journal(f.stateDir); const location = path.join(f.stateDir, info.name);
  await fs.appendFile(location, '{"partial":');
  await assert.rejects(f.uploader.upload(f.options), {code: 'JOURNAL_INVALID'});
  await assert.rejects(f.uploader.reconcile(first.jobId), {code: 'JOURNAL_INVALID'});
  await fs.writeFile(location, info.source.replace('Mochi private test', 'Tampered private title'));
  await assert.rejects(f.uploader.reconcile(first.jobId), {code: 'JOURNAL_INVALID'});
  assert.equal(f.calls.length, 4);
});

test('stale lock is never automatically removed or stolen', async t => {
  const f = await fixture(t, happy); const first = await f.uploader.upload(f.options);
  const location = path.join(f.stateDir, `${first.jobId}.lock`); await fs.mkdir(location);
  await fs.writeFile(path.join(location, 'owner.json'), JSON.stringify({pid: 99999999, createdAt: '2000-01-01'}));
  await assert.rejects(f.uploader.reconcile(first.jobId), {code: 'LOCKED'});
  assert.equal((await fs.stat(location)).isDirectory(), true); assert.equal(f.calls.length, 4);
});

test('token absence and raw local errors cannot expose credentials or server bodies', async t => {
  const f = await fixture(t, happy);
  const uploader = createPrivateUploader({stateDir: f.stateDir, fetchImpl: () => assert.fail('No network allowed'), env: {}});
  await assert.rejects(uploader.check(), {code: 'TOKEN_REQUIRED'});
  await assert.rejects(uploader.upload(f.options), {code: 'TOKEN_REQUIRED'});
  assert.deepEqual(safeError(Error(`${ACCESS} ${SESSION} sensitive body`)), {error: 'LOCAL_STATE_FAILED', message: 'Local state could not be saved or read. Do not retry an upload until the journal is reviewed.'});
});

test('CLI help and invalid arguments are safe without credentials or network', () => {
  const cli = fileURLToPath(new URL('./youtube-private-cli.mjs', import.meta.url));
  const help = spawnSync(process.execPath, [cli, '--help'], {encoding: 'utf8'});
  assert.equal(help.status, 0); assert.match(help.stdout, /no automatic retry/);
  const invalid = spawnSync(process.execPath, [cli, 'upload', '--token', ACCESS], {encoding: 'utf8'});
  assert.equal(invalid.status, 1); assert.ok(!invalid.stderr.includes(ACCESS));
  const missing = spawnSync(process.execPath, [cli, 'upload', '--file', 'no.mp4', '--title', 'Mochi', '--made-for-kids', 'false'], {encoding: 'utf8'});
  assert.equal(missing.status, 1); assert.match(missing.stderr, /CONFIRMATION_REQUIRED/);
});
