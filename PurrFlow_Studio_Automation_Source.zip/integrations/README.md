# Private YouTube integration

This dependency-free Node 22+ uploader is ready for local testing. It has been tested with mocked responses only. It has not uploaded a real video, verified a live OAuth credential, or established unattended operation. It is a separate command-line integration; the Studio web queue remains blocked and does not call it automatically.

The only allowed channel is Mochi Mischief, `UCMbk56GXDq-THOSjZf1HUZg`. Before initiating an upload, the same bearer credential must return exactly that one channel from `channels.list(mine=true)`. Uploads explicitly request `private` visibility, synthetic-media disclosure, and no subscriber notification. The caller must make an explicit audience decision; the tool does not guess whether a video is made for children.

## Run from the Studio directory

Use a secure local process environment to supply `PURRFLOW_YOUTUBE_ACCESS_TOKEN`. Do not paste a token into a command, chat, source file, issue, screenshot, or repository. The tool reads no credential files and writes no access or refresh token. OAuth sign-in and refresh remain external. Upload scope alone may not permit the required channel/receipt checks; the authorized credential must have the appropriate account read and upload permissions. An expired token fails without a retry.

```powershell
node integrations/youtube-private-cli.mjs --help
node integrations/youtube-private-cli.mjs check
node integrations/youtube-private-cli.mjs upload --file "C:\path\mochi.mp4" --title "Mochi private test" --made-for-kids false --confirm-private
node integrations/youtube-private-cli.mjs reconcile --job <jobId>
node --test integrations/youtube-private.test.mjs
```

`false` above is an example, not an audience recommendation. Review the specific video's intended audience and choose `true` or `false`. The module rejects missing or non-boolean declarations. The optional `--description` text defaults to a fictional AI-generated private-test disclosure. There is no public-upload setting, credential argument, or automatic worker.

MP4 validation requires a regular `.mp4` file of 16 bytes to 20 MiB with a plausible initial `ftyp` box. The bytes are read and hashed once, then that exact buffer is uploaded. This checks the container header, not complete decodability, duration, codec, rights or content quality; use the existing FFmpeg/media review before a real test.

## Receipts and recovery

Every attempted upload gets a deterministic job ID from the file hash, normalized metadata, and expected channel. The default private state directory is `integrations/.runtime/youtube-private/`. Preserve it across runs and upgrades. Changing metadata changes the job ID; deduplication does not detect a deliberately altered caption or a different state directory. There is no system-wide or cross-device deduplication.

Each job has a hash-chained append-only journal. Each append is flushed with `FileHandle.sync()` before the next network step; directory sync is attempted on supported systems. The journal saves intent before any request, saves the private session URL before transmitting media, and saves a returned video ID before final verification. On Windows, filesystem modes are not a substitute for account ACLs: keep this folder accessible only to the trusted local user. Journals contain private titles, session URLs and video identifiers; do not commit, publish, screenshot, or upload them. `.gitignore` excludes `.runtime/`; archive/source packaging must also explicitly exclude it.

Same-job concurrent attempts are excluded with an atomic lock directory. A normal exit releases the lock. A process crash leaves the lock in place; the tool never steals a lock based on its age or PID. Before deliberate local lock removal, verify that no process is using that job, preserve the journal, and inspect the owner record. Remove only that job's `.lock` directory, then run `reconcile`. Never remove or truncate a journal to bypass deduplication. This implementation intentionally provides no automatic reset command.

The uploader makes one initiation request and one media request, with no redirects or automatic retries. A repeated `upload` command returns `duplicatePrevented: true` without network activity. After an uncertain result, use the recorded job ID with `reconcile`:

- With a saved video ID, reconciliation checks the channel and reads the video resource.
- With a saved session URL but no video ID, reconciliation checks the channel and uses Google's zero-byte resumable status probe. This is an HTTP `PUT` with no media body; it queries the existing session and never creates another session or resends video bytes.
- An incomplete session reports the stored byte count and requires deliberate manual recovery. This version does not resume media transfer.
- A missing/expired session, unknown initiation result, damaged journal, or crash between request and session persistence requires manual review of YouTube Studio and the private journal. The tool does not start a replacement session, including after a 404.

`uploadAccepted` means a successful upload/status response supplied a video ID. `privateVerified` additionally requires a fresh video-resource read confirming the exact channel, private visibility, synthetic-media disclosure, and explicit audience declaration. `processingComplete` requires both `processingDetails.processingStatus=succeeded` and `status.uploadStatus=processed`. These are distinct results; acceptance is not proof of processing or playable output. A failed/rejected processing status remains visible even when privacy is verified.

CLI exit codes: `0` for a successful channel check or a verified private-video result, `2` for a blocked duplicate/manual-recovery result or invalid command combination, and `1` for a caught operational/validation error. Processing may still be pending when exit code is `0`; inspect `processingComplete` and the returned statuses. Errors contain fixed messages and safe job identifiers, never raw server error bodies, token values, or resumable URLs.

The upload session URL must have HTTPS, the exact `www.googleapis.com` authority and `/upload/youtube/v3/videos` path, a single nonempty `upload_id`, and no userinfo, alternate port, fragment, or normalized path trick. All requests refuse redirects. Protect the trusted local environment and journal; this module is not an Internet-facing upload service or a defense against an attacker who can edit its own source/state.

## Protocol references

Implemented from Google's [resumable upload protocol](https://developers.google.com/youtube/data/guides/using_resumable_upload_protocol), [videos.insert](https://developers.google.com/youtube/data/reference/rest/v3/videos/insert), and [videos.list](https://developers.google.com/youtube/data/reference/rest/v3/videos/list) documentation, reviewed November 20, 2026. The explicit privacy/disclosure settings follow [video status fields](https://developers.google.com/youtube/data/reference/rest/v3/videos#status). This integration imposes a stricter 20 MiB local limit and manual recovery policy.
