import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';

export const EXPECTED_CHANNEL = 'UCMbk56GXDq-THOSjZf1HUZg';
export const MAX_BYTES = 20 * 1024 * 1024;
const API = 'https://www.googleapis.com';
const UPLOAD_PATH = '/upload/youtube/v3/videos';
const DEFAULT_STATE = fileURLToPath(new URL('./.runtime/youtube-private/', import.meta.url));
const hash = value => createHash('sha256').update(value).digest('hex');
const messages = {
  CONFIRMATION_REQUIRED: 'Explicit private-upload confirmation is required.',
  KIDS_DECLARATION_REQUIRED: 'Provide an explicit madeForKids boolean after reviewing the audience.',
  INVALID_METADATA: 'Title or description is invalid.',
  INVALID_MEDIA: 'Provide one regular MP4 with an MP4 file-type header, at most 20 MiB.',
  TOKEN_REQUIRED: 'Set PURRFLOW_YOUTUBE_ACCESS_TOKEN in the process environment using a secure local method.',
  IDENTITY_MISMATCH: 'The authorized channel does not uniquely match Mochi Mischief. Upload blocked.',
  INVALID_SESSION: 'The resumable session endpoint was missing or not allowed. Inspect the private journal.',
  REDIRECT_BLOCKED: 'A redirect was refused. No redirect was followed.',
  NETWORK_UNCERTAIN: 'The request did not complete reliably. Reconcile this job before taking further action.',
  API_REJECTED: 'The API did not accept the request. Reconcile this job before taking further action.',
  INVALID_RESPONSE: 'The API response could not be verified. Reconcile this job.',
  RECEIPT_UNVERIFIED: 'The video response did not verify the expected private channel and disclosure settings.',
  LOCKED: 'This job is locked. Check for a running uploader; crash locks require deliberate local recovery.',
  INVALID_JOB: 'Provide a valid job identifier from a previous uploader result.',
  JOURNAL_INVALID: 'The private journal is missing, incomplete, or damaged. Manual reconciliation is required.',
  LOCAL_STATE_FAILED: 'Local state could not be saved or read. Do not retry an upload until the journal is reviewed.',
};

export class PrivateUploadError extends Error {
  constructor(code, jobId) {
    super(messages[code] || messages.LOCAL_STATE_FAILED);
    this.name = 'PrivateUploadError';
    this.code = messages[code] ? code : 'LOCAL_STATE_FAILED';
    if (/^[a-f0-9]{64}$/.test(jobId || '')) this.jobId = jobId;
  }
}
const fail = (code, jobId) => { throw new PrivateUploadError(code, jobId); };
export function safeError(error) {
  const known = error instanceof PrivateUploadError;
  return {error: known ? error.code : 'LOCAL_STATE_FAILED', message: known ? error.message : messages.LOCAL_STATE_FAILED,
    ...(known && error.jobId ? {jobId: error.jobId} : {})};
}

export function privateMetadata({title, description = 'Original AI-generated Mochi Mischief story. Fictional characters and scenes. Private automation test.', madeForKids} = {}) {
  if (typeof madeForKids !== 'boolean') fail('KIDS_DECLARATION_REQUIRED');
  if (typeof title !== 'string' || !title.trim() || [...title.trim()].length > 100 || /[<>\u0000-\u001f]/.test(title)
      || typeof description !== 'string' || Buffer.byteLength(description, 'utf8') > 5000 || /[<>\u0000]/.test(description)) fail('INVALID_METADATA');
  return {snippet: {title: title.trim(), description, categoryId: '15', tags: ['Mochi Mischief', 'AI cat story']},
    status: {privacyStatus: 'private', containsSyntheticMedia: true, selfDeclaredMadeForKids: madeForKids}};
}

export function validateSessionUrl(raw) {
  let url;
  try { url = new URL(raw); } catch { fail('INVALID_SESSION'); }
  // Check the original authority as well as the parsed URL. Reject encoded path tricks,
  // userinfo, fragments, other ports and normalized paths before adding credentials.
  if (typeof raw !== 'string' || !raw.startsWith(`${API}${UPLOAD_PATH}?`) || raw.length > 8192
      || url.protocol !== 'https:' || url.hostname !== 'www.googleapis.com' || url.port
      || url.username || url.password || url.hash || url.pathname !== UPLOAD_PATH
      || url.searchParams.getAll('upload_id').length !== 1 || !url.searchParams.get('upload_id')) fail('INVALID_SESSION');
  return url.href;
}

async function mediaBytes(file) {
  let handle;
  try {
    if (typeof file !== 'string' || !/\.mp4$/i.test(file)) fail('INVALID_MEDIA');
    handle = await fs.open(file, 'r');
    const before = await handle.stat();
    if (!before.isFile() || before.size < 16 || before.size > MAX_BYTES) fail('INVALID_MEDIA');
    const bytes = Buffer.alloc(before.size);
    let offset = 0;
    while (offset < bytes.length) {
      const result = await handle.read(bytes, offset, bytes.length - offset, offset);
      if (!result.bytesRead) fail('INVALID_MEDIA');
      offset += result.bytesRead;
    }
    const after = await handle.stat();
    const boxSize = bytes.readUInt32BE(0);
    if (after.size !== before.size || after.mtimeMs !== before.mtimeMs || bytes.toString('ascii', 4, 8) !== 'ftyp'
        || boxSize < 16 || boxSize > bytes.length) fail('INVALID_MEDIA');
    return bytes;
  } catch (error) {
    if (error instanceof PrivateUploadError) throw error;
    fail('INVALID_MEDIA');
  } finally { await handle?.close(); }
}

async function syncDirectory(dir) {
  // FileHandle.sync is the durability barrier for every journal append. Directory
  // fsync is also attempted where the OS supports opening directories (not Windows).
  let handle;
  try { handle = await fs.open(dir, 'r'); await handle.sync(); } catch {} finally { await handle?.close(); }
}

function publicState(state, extra = {}) {
  return {jobId: state.jobId, phase: state.phase, uploadAccepted: state.uploadAccepted === true,
    privateVerified: state.privateVerified === true, processingComplete: state.processingComplete === true,
    ...(state.videoId ? {videoId: state.videoId} : {}), ...(state.processingStatus ? {processingStatus: state.processingStatus} : {}),
    ...(state.uploadStatus ? {uploadStatus: state.uploadStatus} : {}), ...(Number.isInteger(state.receivedBytes) ? {receivedBytes: state.receivedBytes} : {}),
    ...(state.attention ? {attention: state.attention} : {}), ...extra};
}

export function createPrivateUploader({stateDir = DEFAULT_STATE, fetchImpl = globalThis.fetch, env = process.env, timeoutMs = 90_000} = {}) {
  const root = path.resolve(stateDir);
  function token() {
    const value = env.PURRFLOW_YOUTUBE_ACCESS_TOKEN;
    if (typeof value !== 'string' || value.length < 10 || value.length > 8192 || !/^[\x21-\x7e]+$/.test(value)) fail('TOKEN_REQUIRED');
    return value;
  }
  async function request(url, options, accessToken) {
    let response;
    try {
      response = await fetchImpl(url, {...options, headers: {...options.headers, Authorization: `Bearer ${accessToken}`},
        redirect: 'manual', signal: AbortSignal.timeout(timeoutMs)});
    } catch { fail('NETWORK_UNCERTAIN'); }
    if (response.status >= 300 && response.status < 400 && response.status !== 308) fail('REDIRECT_BLOCKED');
    return response;
  }
  async function json(response) {
    try {
      // Bounded parsing; do not retain or report raw API bodies.
      if (Number(response.headers.get('content-length') || 0) > 1024 * 1024) fail('INVALID_RESPONSE');
      const reader = response.body?.getReader();
      if (!reader) fail('INVALID_RESPONSE');
      const chunks = []; let length = 0;
      while (true) {
        const {done, value} = await reader.read();
        if (done) break;
        length += value.length;
        if (length > 1024 * 1024) { await reader.cancel(); fail('INVALID_RESPONSE'); }
        chunks.push(value);
      }
      return JSON.parse(Buffer.concat(chunks).toString('utf8'));
    } catch { fail('INVALID_RESPONSE'); }
  }
  async function identity(accessToken) {
    const response = await request(`${API}/youtube/v3/channels?part=id&mine=true&maxResults=50`, {method: 'GET'}, accessToken);
    if (response.status !== 200) fail('API_REJECTED');
    const body = await json(response);
    if (!Array.isArray(body.items) || body.items.length !== 1 || body.items[0].id !== EXPECTED_CHANNEL || body.nextPageToken) fail('IDENTITY_MISMATCH');
    return {verified: true, channelId: EXPECTED_CHANNEL, uploadAttempted: false};
  }
  const journalPath = jobId => path.join(root, `${jobId}.jsonl`);
  async function readJournal(jobId, missingAllowed = false) {
    try {
      const location = journalPath(jobId);
      if ((await fs.lstat(location)).isSymbolicLink()) fail('JOURNAL_INVALID');
      const source = await fs.readFile(location, 'utf8');
      if (!source.endsWith('\n') || !source.trim()) fail('JOURNAL_INVALID');
      let previous = null; let seq = 0; let last;
      for (const line of source.trimEnd().split('\n')) {
        const entry = JSON.parse(line);
        const expected = hash(JSON.stringify({seq: entry.seq, previous: entry.previous, state: entry.state}));
        if (entry.seq !== ++seq || entry.previous !== previous || entry.digest !== expected || entry.state?.jobId !== jobId
            || entry.state?.expectedChannel !== EXPECTED_CHANNEL) fail('JOURNAL_INVALID');
        previous = entry.digest; last = entry.state;
      }
      if (!last || !/^[a-f0-9]{64}$/.test(last.fileHash || '') || !Number.isInteger(last.byteLength) || last.byteLength < 16 || last.byteLength > MAX_BYTES
          || JSON.stringify(privateMetadata({title: last.metadata?.snippet?.title, description: last.metadata?.snippet?.description,
            madeForKids: last.metadata?.status?.selfDeclaredMadeForKids})) !== JSON.stringify(last.metadata)
          || hash(JSON.stringify({fileHash: last.fileHash, metadata: last.metadata, expectedChannel: EXPECTED_CHANNEL})) !== jobId) fail('JOURNAL_INVALID');
      if (last.sessionUrl) validateSessionUrl(last.sessionUrl);
      if (last.videoId && !/^[A-Za-z0-9_-]{11}$/.test(last.videoId)) fail('JOURNAL_INVALID');
      return {state: last, seq, digest: previous};
    } catch (error) {
      if (error?.code === 'ENOENT' && missingAllowed) return null;
      fail('JOURNAL_INVALID', jobId);
    }
  }
  async function append(current, state) {
    const payload = {seq: (current?.seq || 0) + 1, previous: current?.digest || null, state: {...state, updatedAt: new Date().toISOString()}};
    const entry = {...payload, digest: hash(JSON.stringify(payload))};
    let handle;
    try {
      handle = await fs.open(journalPath(state.jobId), current ? 'a' : 'wx', 0o600);
      await handle.writeFile(JSON.stringify(entry) + '\n');
      await handle.sync();
      if (!current) await syncDirectory(root);
      return {state: entry.state, seq: entry.seq, digest: entry.digest};
    } catch { fail('LOCAL_STATE_FAILED', state.jobId); } finally { await handle?.close(); }
  }
  async function locked(jobId, fn) {
    await fs.mkdir(root, {recursive: true, mode: 0o700});
    const lock = path.join(root, `${jobId}.lock`);
    try { await fs.mkdir(lock, {mode: 0o700}); } catch (error) { if (error?.code === 'EEXIST') fail('LOCKED', jobId); fail('LOCAL_STATE_FAILED', jobId); }
    try {
      await fs.writeFile(path.join(lock, 'owner.json'), JSON.stringify({pid: process.pid, createdAt: new Date().toISOString()}), {flag: 'wx', mode: 0o600});
      return await fn();
    } catch (error) {
      if (error instanceof PrivateUploadError) { error.jobId = jobId; throw error; }
      fail('LOCAL_STATE_FAILED', jobId);
    } finally {
      // Deliberately never steal crash locks. Remove only this operation's lock.
      await fs.unlink(path.join(lock, 'owner.json')).catch(() => {});
      await fs.rmdir(lock).catch(() => {});
    }
  }
  function receipt(video, state) {
    if (!video || video.id !== state.videoId || video.snippet?.channelId !== EXPECTED_CHANNEL
        || video.status?.privacyStatus !== 'private' || video.status?.containsSyntheticMedia !== true
        || video.status?.selfDeclaredMadeForKids !== state.metadata.status.selfDeclaredMadeForKids) fail('RECEIPT_UNVERIFIED');
    const processingStatus = ['processing', 'succeeded', 'failed', 'terminated'].includes(video.processingDetails?.processingStatus) ? video.processingDetails.processingStatus : 'unknown';
    const uploadStatus = ['uploaded', 'processed', 'failed', 'rejected', 'deleted'].includes(video.status?.uploadStatus) ? video.status.uploadStatus : 'unknown';
    return {...state, phase: 'private_verified', privateVerified: true, processingStatus, uploadStatus,
      processingComplete: processingStatus === 'succeeded' && uploadStatus === 'processed', attention: null};
  }
  async function verifyVideo(state, accessToken) {
    const response = await request(`${API}/youtube/v3/videos?part=snippet,status,processingDetails&id=${state.videoId}`, {method: 'GET'}, accessToken);
    if (response.status !== 200) fail('API_REJECTED');
    const body = await json(response);
    if (!Array.isArray(body.items) || body.items.length !== 1) fail('RECEIPT_UNVERIFIED');
    return receipt(body.items[0], state);
  }
  async function accepted(response, state, save, accessToken) {
    if (![200, 201].includes(response.status)) fail('API_REJECTED');
    const video = await json(response);
    if (!/^[A-Za-z0-9_-]{11}$/.test(video?.id || '')) fail('INVALID_RESPONSE');
    state = {...state, phase: 'upload_accepted', uploadAccepted: true, videoId: video.id};
    await save(state); // Save the video identifier even if final verification fails.
    state = await verifyVideo(state, accessToken);
    await save(state);
    return publicState(state);
  }
  async function upload(options = {}) {
    if (options.confirmPrivate !== true) fail('CONFIRMATION_REQUIRED');
    const metadata = privateMetadata(options);
    const bytes = await mediaBytes(options.file);
    const accessToken = token();
    const fileHash = hash(bytes);
    const jobId = hash(JSON.stringify({fileHash, metadata, expectedChannel: EXPECTED_CHANNEL}));
    return locked(jobId, async () => {
      let current = await readJournal(jobId, true);
      if (current) return publicState(current.state, {duplicatePrevented: true, uploadAttempted: false, nextAction: 'reconcile'});
      let state = {version: 1, jobId, fileHash, byteLength: bytes.length, expectedChannel: EXPECTED_CHANNEL, metadata,
        phase: 'intent_saved', uploadAccepted: false, privateVerified: false, processingComplete: false};
      const save = async next => { current = await append(current, next); state = current.state; };
      await save(state); // Persist intent before the first network request.
      try {
        await identity(accessToken);
        await save({...state, phase: 'initiation_pending'});
        const body = JSON.stringify(metadata);
        const initiation = await request(`${API}${UPLOAD_PATH}?uploadType=resumable&part=snippet,status&notifySubscribers=false`,
          {method: 'POST', headers: {'Content-Type': 'application/json; charset=UTF-8', 'Content-Length': String(Buffer.byteLength(body)),
            'X-Upload-Content-Length': String(bytes.length), 'X-Upload-Content-Type': 'video/mp4'}, body}, accessToken);
        if (![200, 201].includes(initiation.status)) fail('API_REJECTED');
        const sessionUrl = validateSessionUrl(initiation.headers.get('location'));
        await save({...state, phase: 'session_saved', sessionUrl}); // Durable session before any media bytes.
        await save({...state, phase: 'bytes_pending'});
        const response = await request(sessionUrl, {method: 'PUT', headers: {'Content-Type': 'video/mp4', 'Content-Length': String(bytes.length)}, body: bytes}, accessToken);
        return await accepted(response, state, save, accessToken);
      } catch (error) {
        await save({...state, phase: 'attention_required', privateVerified: false, processingComplete: false, attention: safeError(error).error});
        throw error;
      }
    });
  }
  async function reconcile(jobId) {
    if (!/^[a-f0-9]{64}$/.test(jobId || '')) fail('INVALID_JOB');
    return locked(jobId, async () => {
      let current = await readJournal(jobId);
      let state = current.state;
      const save = async next => { current = await append(current, next); state = current.state; };
      if (!state.videoId && !state.sessionUrl) {
        return publicState(state, {nextAction: 'manual_reconciliation', uploadAttempted: false});
      }
      const accessToken = token();
      await save({...state, phase: 'reconciling'});
      try {
        await identity(accessToken);
        if (state.videoId) {
          await save(await verifyVideo(state, accessToken));
          return publicState(state, {uploadAttempted: false});
        }
        const sessionUrl = validateSessionUrl(state.sessionUrl);
        // Protocol status probe only: empty PUT, never resend media or create a session.
        const response = await request(sessionUrl, {method: 'PUT', headers: {'Content-Length': '0', 'Content-Range': `bytes */${state.byteLength}`}, body: Buffer.alloc(0)}, accessToken);
        if (response.status === 308) {
          const range = response.headers.get('range');
          let receivedBytes = 0;
          if (range) {
            const match = /^bytes=0-(\d+)$/.exec(range);
            if (!match || !Number.isSafeInteger(Number(match[1])) || Number(match[1]) >= state.byteLength) fail('INVALID_RESPONSE');
            receivedBytes = Number(match[1]) + 1;
          }
          await save({...state, phase: 'incomplete', receivedBytes, privateVerified: false, processingComplete: false, attention: 'MANUAL_RECOVERY_REQUIRED'});
          return publicState(state, {nextAction: 'manual_recovery', uploadAttempted: false});
        }
        if (response.status === 404 || response.status === 410) {
          await save({...state, phase: 'session_unavailable', attention: 'MANUAL_RECONCILIATION_REQUIRED'});
          return publicState(state, {nextAction: 'manual_reconciliation', uploadAttempted: false});
        }
        return await accepted(response, state, save, accessToken);
      } catch (error) {
        await save({...state, phase: 'attention_required', privateVerified: false, processingComplete: false, attention: safeError(error).error});
        throw error;
      }
    });
  }
  return {check: async () => identity(token()), upload, reconcile};
}
