#!/usr/bin/env node
import {parseArgs} from 'node:util';
import {createPrivateUploader, safeError} from './youtube-private.mjs';

const help = `PurrFlow private YouTube uploader (Node 22+, no dependencies)
  node integrations/youtube-private-cli.mjs check
  node integrations/youtube-private-cli.mjs upload --file <video.mp4> --title <title> --made-for-kids <true|false> --confirm-private
  node integrations/youtube-private-cli.mjs reconcile --job <jobId>

Set PURRFLOW_YOUTUBE_ACCESS_TOKEN securely in the process environment.
The audience choice is required. Never paste credentials into command arguments.
Upload always creates a PRIVATE, synthetic-media video on the verified Mochi channel.
Reconcile checks existing state only; it never creates sessions or resends video bytes.
Runtime journals and session URLs are private. Preserve .runtime for deduplication.
There is no automatic retry, lock takeover, token refresh or public publishing.
`;

try {
  const {values, positionals} = parseArgs({allowPositionals: true, strict: true, options: {
    help: {type: 'boolean'}, file: {type: 'string'}, title: {type: 'string'}, description: {type: 'string'},
    'made-for-kids': {type: 'string'}, 'confirm-private': {type: 'boolean'}, job: {type: 'string'},
  }});
  if (values.help || positionals.length === 0) console.log(help);
  else {
    const command = positionals[0];
    const allowed = command === 'upload' ? ['file', 'title', 'description', 'made-for-kids', 'confirm-private'] : command === 'reconcile' ? ['job'] : [];
    if (positionals.length !== 1 || !['check', 'upload', 'reconcile'].includes(command) || Object.keys(values).some(key => !allowed.includes(key))) {
      console.error(JSON.stringify({error: 'INVALID_ARGUMENTS', message: 'Use --help for accepted commands and options.'})); process.exitCode = 2;
    } else {
      const uploader = createPrivateUploader();
      let result;
      if (command === 'check') result = await uploader.check();
      if (command === 'reconcile') result = await uploader.reconcile(values.job);
      if (command === 'upload') result = await uploader.upload({file: values.file, title: values.title,
        ...(values.description !== undefined ? {description: values.description} : {}),
        madeForKids: values['made-for-kids'] === 'true' ? true : values['made-for-kids'] === 'false' ? false : undefined,
        confirmPrivate: values['confirm-private'] === true});
      console.log(JSON.stringify(result));
      if (result.duplicatePrevented || (command !== 'check' && !result.privateVerified)) process.exitCode = 2;
    }
  }
} catch (error) { console.error(JSON.stringify(safeError(error))); process.exitCode = 1; }
