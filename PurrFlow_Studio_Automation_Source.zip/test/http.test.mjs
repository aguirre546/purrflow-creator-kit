import test from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {request} from 'node:http';
import {mkdtemp,readFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url));
test('HTTP saves concurrent campaigns, persists a restart, and blocks unsafe requests',async()=>{
 const dir=await mkdtemp(path.join(tmpdir(),'purrflow-test-'));
 const port=4321,base=`http://127.0.0.1:${port}`;let child;
 async function start(){child=spawn(process.execPath,['server.mjs'],{cwd:root,env:{...process.env,PORT:String(port),PURRFLOW_DATA:dir},stdio:['ignore','pipe','pipe']});await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Server startup timed out')),10000);child.once('error',reject);child.once('exit',code=>reject(Error(`Server exited ${code}`)));child.stdout.once('data',()=>{clearTimeout(timer);resolve();});});}
 async function stop(){if(child&&child.exitCode===null)await new Promise(resolve=>{child.once('exit',resolve);child.kill();});}
 try{
  await start();
  const status=await(await fetch(base+'/api/status')).json();assert.equal(status.generation,'not_connected');assert(Object.values(status.publishers).every(v=>v===false));
  const rejectedHost=await new Promise((resolve,reject)=>{const req=request(base+'/api/status',{headers:{Host:'untrusted.example'}},res=>{res.resume();res.once('end',()=>resolve(res.statusCode));});req.once('error',reject);req.end();});
  assert.equal(rejectedHost,403);
  const input={idea:'Mochi inspects his tiny cardboard box',platforms:['youtube','tiktok'],scheduledAt:new Date(Date.now()+3600000).toISOString()};
  const create=()=>fetch(base+'/api/campaigns',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(input)});
  const results=await Promise.all(Array.from({length:5},create));assert(results.every(r=>r.status===201));
  const cs=await(await fetch(base+'/api/campaigns')).json();assert.equal(cs.length,5);assert(cs.every(c=>c.jobs.every(j=>j.status==='blocked')));
  const control=(action,value)=>fetch(base+`/api/campaigns/${cs[1].id}/${action}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(value)});
  assert.equal((await control('pause',{})).status,200);
  await fetch(base+'/api/run',{method:'POST'});
  let controlled=(await(await fetch(base+'/api/campaigns')).json()).find(c=>c.id===cs[1].id);
  assert.equal(controlled.paused,true);assert.equal(controlled.state,'paused');assert(controlled.jobs.every(j=>j.attempts===0));
  assert.equal((await control('schedule',{scheduledAt:new Date(Date.now()-1000).toISOString()})).status,400);
  controlled=(await(await fetch(base+'/api/campaigns')).json()).find(c=>c.id===cs[1].id);assert.equal(controlled.paused,true);
  const later=new Date(Date.now()+7200000).toISOString();
  assert.equal((await control('schedule',{scheduledAt:later})).status,200);
  controlled=(await(await fetch(base+'/api/campaigns')).json()).find(c=>c.id===cs[1].id);
  assert.equal(controlled.paused,false);assert.equal(controlled.scheduledAt,later);assert(controlled.jobs.every(j=>j.status==='blocked'&&j.nextAttemptAt===Date.parse(later)));
  assert.equal((await fetch(base+'/api/run',{method:'POST',headers:{Origin:'https://untrusted.example'}})).status,403);
  const before=structuredClone(cs[0].drafts);const invalid=structuredClone(before);invalid.youtube.caption='must not persist';delete invalid.tiktok;assert.equal((await fetch(base+`/api/campaigns/${cs[0].id}/drafts`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(invalid)})).status,400);const unchanged=await(await fetch(base+'/api/campaigns')).json();assert.deepEqual(unchanged[0].drafts,before);

  assert.equal((await fetch(base+`/api/campaigns/${cs[0].id}/video`,{method:'POST',headers:{'Content-Type':'video/mp4'},body:'not a video'})).status,400);
  assert.equal((await fetch(base+'/api/run',{method:'POST'})).status,200);
  assert.equal(JSON.parse(await readFile(path.join(dir,'campaigns.json'),'utf8')).length,5);
  await stop();await start();const restored=await(await fetch(base+'/api/campaigns')).json();assert.equal(restored.length,5);assert(restored.every(c=>c.jobs.every(j=>j.attempts===0)));
 }finally{await stop();await rm(dir,{recursive:true,force:true});}
});
