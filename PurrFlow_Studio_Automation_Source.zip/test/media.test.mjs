import test from 'node:test';
import assert from 'node:assert/strict';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {access, mkdtemp, readFile, writeFile, rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {inspectVideo} from '../media.mjs';
import {renderCaptions, narrativeCues} from '../captions.mjs';

const run=promisify(execFile);
const ffmpeg=process.env.PURRFLOW_FFMPEG||'C:/Users/MACKY/Documents/Codex/2026-10-14/generate-me-a-video-what-if/work/pydeps/imageio_ffmpeg/binaries/ffmpeg-win-x86_64-v7.1.exe';
let available=true;try{await access(ffmpeg);}catch{available=false;}

test('unavailable media validation blocks publishing',async()=>{
 assert.equal((await inspectVideo('missing.mp4')).passed,false);
 assert.equal((await inspectVideo('missing.mp4','missing-executable')).passed,false);
});

test('decoder corruption fails validation and caption rendering even when ordinary FFmpeg exits successfully',{skip:!available,timeout:90000},async()=>{
 const working=await mkdtemp(path.join(tmpdir(),'purrflow-corrupt-'));
 try{
  const input=path.join(working,'input.mp4'),corrupt=path.join(working,'corrupt.mp4'),output=path.join(working,'output.mp4');
  await run(ffmpeg,['-hide_banner','-nostdin','-y','-f','lavfi','-i','testsrc2=s=720x1280:r=2:d=15','-c:v','libx264','-preset','ultrafast','-pix_fmt','yuv420p',input],{timeout:30000,windowsHide:true});
  assert.equal((await inspectVideo(input,ffmpeg)).passed,true);
  const bytes=await readFile(input),mdat=bytes.indexOf(Buffer.from('mdat')),samples=bytes.indexOf(Buffer.from('stsz'));
  assert(mdat>0&&samples>0,'MP4 fixture contains its media and sample size table');
  // Corrupt one middle sample while retaining the container metadata and the
  // remaining decodable frames. Plain FFmpeg conceals the error and exits 0.
  assert.equal(bytes.readUInt32BE(samples+8),0,'fixture stores individual sample sizes');
  const count=bytes.readUInt32BE(samples+12),middle=Math.floor(count/2);
  let offset=mdat+4;for(let index=0;index<middle;index++)offset+=bytes.readUInt32BE(samples+16+index*4);
  const size=bytes.readUInt32BE(samples+16+middle*4);
  bytes.fill(0xff,offset+4,offset+Math.min(size,256));await writeFile(corrupt,bytes);
  const ordinary=await run(ffmpeg,['-hide_banner','-nostdin','-i',corrupt,'-map','0:v:0','-an','-f','null','-'],{timeout:30000,windowsHide:true});
  assert.match(ordinary.stderr,/error|invalid|corrupt/iu);
  const quality=await inspectVideo(corrupt,ffmpeg);assert.equal(quality.passed,false);assert.match(quality.reason,/could not be decoded/);
  await assert.rejects(renderCaptions({input:corrupt,output,ffmpeg,cues:narrativeCues('Mochi tests a box')}));
  await assert.rejects(access(output));
 }finally{await rm(working,{recursive:true,force:true});}
});
