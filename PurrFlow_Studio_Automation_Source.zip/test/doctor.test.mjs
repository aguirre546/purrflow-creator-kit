import test from 'node:test';
import assert from 'node:assert/strict';
import {inspectReadiness} from '../doctor.mjs';

const policy = {generation: {existingCreditsOnly: true, allowNewCharges: false}};
test('configuration is never reported as verified access and secret values are absent', async () => {
  const env = {PURRFLOW_YOUTUBE_WEBHOOK: 'https://publisher.example/private-path',
    PURRFLOW_WEBHOOK_TOKEN: 'private-bearer-token', PURRFLOW_YOUTUBE_ACCOUNT_ID: 'private-account',
    PURRFLOW_YOUTUBE_ACCESS_TOKEN: 'oauth-private', PURRFLOW_ALERT_WEBHOOK: 'https://alerts.example/private',
    PURRFLOW_ALERT_TOKEN: 'private-alert-token'};
  const result = await inspectReadiness({env, policy, nodeVersion: '22.1.0'});
  assert.equal(result.readyForUnattendedOperation, false);
  assert.equal(result.sendsNetworkRequests, false);
  assert.equal(result.checks.find(c => c.id === 'youtube_publisher').state, 'configured_unverified');
  assert.equal(result.checks.find(c => c.id === 'youtube_private_test').state, 'configured_unverified');
  for (const secret of Object.values(env)) assert.equal(JSON.stringify(result).includes(secret), false);
});
test('bad policy, old runtime and insecure endpoint fail configuration checks', async () => {
  const result = await inspectReadiness({env: {PURRFLOW_YOUTUBE_WEBHOOK: 'https://user:secret@example.com'},
    nodeVersion: '20.0.0', policy: {generation: {existingCreditsOnly: false, allowNewCharges: true}}});
  for (const id of ['node', 'budget_policy']) assert.equal(result.checks.find(c => c.id === id).state, 'blocked');
  assert.equal(result.checks.find(c => c.id === 'youtube_publisher').state, 'invalid');
});
test('media capability check does not expose a failed executable or error output', async () => {
  const env = {PURRFLOW_FFMPEG: 'private-executable-path'};
  const failed = await inspectReadiness({env, policy, run: async () => { throw Error('private-error'); }});
  assert.equal(failed.checks.find(c => c.id === 'media').state, 'blocked');
  assert(!JSON.stringify(failed).includes('private-error'));
  assert(!JSON.stringify(failed).includes(env.PURRFLOW_FFMPEG));
  const working = await inspectReadiness({env, policy,
    run: async (_file, args) => ({stdout: args.includes('-encoders') ? ' V libx264 H.264' : ' ... ass V->V captions'})});
  assert.equal(working.checks.find(c => c.id === 'media').state, 'passed');
  assert.equal(working.readyForUnattendedOperation, false);
});
