import test from 'node:test';
import assert from 'node:assert/strict';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {mkdtemp, rm, access, writeFile, readFile} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {renderCaptions, narrativeCues} from '../captions.mjs';

const run = promisify(execFile);
const ffmpeg = process.env.PURRFLOW_FFMPEG || 'C:/Users/MACKY/Documents/Codex/2026-10-14/generate-me-a-video-what-if/work/pydeps/imageio_ffmpeg/binaries/ffmpeg-win-x86_64-v7.1.exe';
let available = true;
try { await access(ffmpeg); } catch { available = false; }

test('narrative fallback does not repeat unverified story details or claim a transcript', () => {
  const cues = narrativeCues('Mochi drives a red spaceship and speaks English.');
  assert.equal(cues.length, 3);
  assert.ok(!JSON.stringify(cues).includes('spaceship'));
  assert.throws(() => narrativeCues(''), /idea/);
});

test('renderer rejects invalid cues before invoking a process', async () => {
  for (const cues of [[], [{start: 0, end: 16, text: 'a'}], [{start: 1, end: 2, text: 'a'}, {start: 1.5, end: 3, text: 'b'}], [{start: NaN, end: 1, text: 'a'}], [{start: 0, end: 1, text: '\u0000'}], [{start: 0, end: 1, text: 'x'.repeat(53)}]]) {
    await assert.rejects(renderCaptions({cues, ffmpeg: 'not-executed'}), /Caption|caption|Provide/);
  }
});

test('renderer requires explicit executable and separate absolute output', async () => {
  const cues = narrativeCues('A cat story');
  await assert.rejects(renderCaptions({cues}), /FFmpeg/);
  await assert.rejects(renderCaptions({input: 'relative.mp4', output: 'relative.mp4', ffmpeg, cues}), /absolute/);
});

test('real FFmpeg burns narrative overlays, preserves audio, and refuses overwrite', {skip: !available, timeout: 120000}, async () => {
  const working = await mkdtemp(path.join(tmpdir(), 'purrflow-caption-test-'));
  try {
    const input = path.join(working, 'input.mp4');
    const output = path.join(working, 'output.mp4');
    await run(ffmpeg, ['-hide_banner', '-nostdin', '-y', '-f', 'lavfi', '-i', 'color=c=blue:s=720x1280:r=2:d=15', '-f', 'lavfi', '-i', 'sine=frequency=440:duration=15', '-c:v', 'libx264', '-preset', 'ultrafast', '-c:a', 'aac', '-shortest', input], {timeout: 30000, windowsHide: true});
    const result = await renderCaptions({input, output, ffmpeg, cues: narrativeCues('Mochi story')});
    assert.equal(result.burnedIn, true);
    assert.equal(result.kind, 'narrative');
    const sourceFrame = await run(ffmpeg, ['-hide_banner', '-i', input, '-frames:v', '1', '-f', 'md5', '-'], {windowsHide: true});
    const captionFrame = await run(ffmpeg, ['-hide_banner', '-i', output, '-frames:v', '1', '-f', 'md5', '-'], {windowsHide: true});
    assert.notEqual(sourceFrame.stdout, captionFrame.stdout);
    const decoded = await run(ffmpeg, ['-hide_banner', '-i', output, '-f', 'null', '-'], {windowsHide: true});
    assert.match(decoded.stderr, /720x1280/);
    assert.match(decoded.stderr, /Audio:/);
    const marker = path.join(working, 'existing.mp4');
    await writeFile(marker, 'preserve');
    await assert.rejects(renderCaptions({input, output: marker, ffmpeg, cues: [{start: 0, end: 1, text: 'Literal {\\pos(0,0)} text'}]}), /EEXIST/);
    assert.equal(await readFile(marker, 'utf8'), 'preserve');
  } finally {
    await rm(working, {recursive: true, force: true});
  }
});
