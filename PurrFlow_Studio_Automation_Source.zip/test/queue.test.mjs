import test from'node:test';import assert from'node:assert/strict';import{campaign,ready,tick,recover,platforms,reschedule,validateDrafts,validateReceipt}from'../core.mjs';
const make=()=>campaign({idea:'Mochi investigates the empty snack box',platforms:['youtube','x'],scheduledAt:new Date(200000).toISOString()},100000);
test('one campaign has different platform captions and a shared release time',()=>{const c=campaign({idea:'Mochi chooses a cardboard box over his new cat bed',platforms,scheduledAt:new Date(200000).toISOString()},100000);assert.equal(new Set(Object.values(c.drafts).map(d=>d.caption)).size,5);assert(c.jobs.every(j=>j.nextAttemptAt===200000));assert(c.drafts.x.caption.length<280);});
test('all due destinations start together without waiting for the slowest publisher',async()=>{const c=campaign({idea:'Mochi chooses a cardboard box over his new cat bed',platforms,scheduledAt:new Date(200000).toISOString()},100000);c.videoPath='same-clip.mp4';c.mediaQuality={passed:true};const started=[];let release;const gate=new Promise(r=>release=r);const adapters=Object.fromEntries(platforms.map(p=>[p,async({campaign:input})=>{started.push({p,video:input.videoPath,caption:input.drafts[p].caption});await gate;return {postId:p};}]));const running=tick(c,adapters,{now:200000});await new Promise(r=>setImmediate(r));assert.equal(started.length,5);assert(started.every(s=>s.video==='same-clip.mp4'));release();await running;assert.equal(c.state,'completed');});
test('reject invalid destinations, past schedules and empty ideas',()=>{assert.throws(()=>campaign({idea:'x'}));assert.throws(()=>campaign({idea:'An original cat story',platforms:['bad'],scheduledAt:new Date(Date.now()+10000)}));});
test('missing connections stay blocked and never call a publisher',async()=>{const c=make();c.videoPath='clip.mp4';c.mediaQuality={passed:true};await tick(c,{}, {now:300000});assert(c.jobs.every(j=>j.status==='blocked'&&j.attempts===0));});
test('scheduled jobs wait, successful destinations never publish twice',async()=>{const c=make();c.videoPath='clip.mp4';c.mediaQuality={passed:true};let calls=0;const a={youtube:async()=>({postId:String(++calls)})};await tick(c,a,{now:199999});assert.equal(calls,0);await tick(c,a,{now:200000});await tick(c,a,{now:300000});assert.equal(calls,1);assert.equal(c.jobs[0].status,'published');assert.equal(c.jobs[1].status,'blocked');});
test('transient errors back off and stop after bounded attempts',async()=>{const c=make();c.videoPath='clip.mp4';c.mediaQuality={passed:true};const a={youtube:async()=>{throw Error('Temporary failure');}};await tick(c,a,{now:200000});assert.equal(c.jobs[0].nextAttemptAt,260000);await tick(c,a,{now:210000});assert.equal(c.jobs[0].attempts,1);await tick(c,a,{now:260000});await tick(c,a,{now:380000});assert.equal(c.jobs[0].status,'failed');});
test('ambiguous delivery never retries automatically',async()=>{const c=make();c.videoPath='clip.mp4';c.mediaQuality={passed:true};let calls=0;const a={youtube:async()=>{calls++;return {};}};await tick(c,a,{now:200000});await tick(c,a,{now:900000});assert.equal(calls,1);assert.equal(c.jobs[0].status,'needs_attention');});
test('restart requires delivery reconciliation for interrupted jobs',()=>{const c=make();c.jobs[0].status='processing';recover(c);assert.equal(c.jobs[0].status,'needs_attention');});
test('disconnecting and reconnecting cannot reset an ambiguous or failed delivery',async()=>{const c=make();c.videoPath='clip.mp4';c.mediaQuality={passed:true};c.jobs[0].status='needs_attention';c.jobs[1].status='failed';ready(c,{});let calls=0;const adapter=async()=>{calls++;return {postId:'duplicate'};};await tick(c,{youtube:adapter,x:adapter},{now:900000});assert.equal(calls,0);assert.equal(c.jobs[0].status,'needs_attention');assert.equal(c.jobs[1].status,'failed');assert.equal(c.state,'needs_attention');});

test('unvalidated media never dispatches even with connected publishers',async()=>{const c=make();c.videoPath='unverified.mp4';let calls=0;await tick(c,{youtube:async()=>{calls++;return {postId:'bad'};}},{now:300000});assert.equal(calls,0);assert(c.jobs.every(j=>j.status==='blocked'));assert.equal(c.state,'blocked');});

test('overdue first attempts hold before a newly connected adapter can send',async()=>{const c=make();c.videoPath='clip.mp4';c.mediaQuality={passed:true};let calls=0;await tick(c,{youtube:async()=>{calls++;return {postId:'unexpected'};}},{now:900000});assert.equal(calls,0);assert.equal(c.jobs[0].status,'schedule_hold');reschedule(c,new Date(1100000).toISOString(),900000);await tick(c,{youtube:async()=>{calls++;return {postId:'expected'};}},{now:1100000});assert.equal(calls,1);});
test('rescheduling cannot reset ambiguous delivery and preserves published jobs',()=>{const c=make();c.jobs[0].status='needs_attention';assert.throws(()=>reschedule(c,new Date(1100000).toISOString(),900000));c.jobs[0].status='published';c.jobs[0].postId='done';reschedule(c,new Date(1100000).toISOString(),900000);assert.equal(c.jobs[0].postId,'done');assert.equal(c.jobs[0].status,'published');});
test('paused campaign never publishes',async()=>{const c=make();c.paused=true;c.videoPath='clip.mp4';c.mediaQuality={passed:true};let calls=0;await tick(c,{youtube:async()=>{calls++;return {postId:'bad'};}},{now:200000});assert.equal(calls,0);assert.equal(c.state,'paused');});
test('draft limits include hashtags and reject unsafe or excessive tags',()=>{const c=make();assert.doesNotThrow(()=>validateDrafts(c.drafts,['youtube','x']));c.drafts.x.caption='x'.repeat(240);assert.throws(()=>validateDrafts(c.drafts,['x']));c.drafts.x.caption='A cat story';c.drafts.x.hashtags=['bad tag'];assert.throws(()=>validateDrafts(c.drafts,['x']));});
test('publisher must verify account, platform, completed public status and URL',()=>{const good={platform:'youtube',accountId:'expected',status:'published',visibility:'public',postId:'abc',url:'https://youtube.com/shorts/abc'};assert.equal(validateReceipt(good,{platform:'youtube',accountId:'expected'}),good);for(const change of [{accountId:'wrong'},{status:'processing'},{visibility:'private'},{url:'javascript:alert(1)'}])assert.throws(()=>validateReceipt({...good,...change},{platform:'youtube',accountId:'expected'}));});

test('editing holds due media and copy until the replacement is committed',async()=>{
 const c=make();c.videoPath='old.mp4';c.mediaQuality={passed:true};const sent=[];
 const adapters={youtube:async({campaign:current})=>{sent.push({video:current.videoPath,caption:current.drafts.youtube.caption});return {postId:'new-only'};}};
 ready(c,adapters);c.editing=true;
 await tick(c,adapters,{now:200000});
 assert.equal(sent.length,0);assert.equal(c.jobs[0].attempts,0);assert.equal(c.jobs[0].status,'queued');
 c.videoPath='replacement.mp4';c.drafts.youtube.caption='Committed replacement caption';delete c.editing;
 await tick(c,adapters,{now:200000});
 assert.deepEqual(sent,[{video:'replacement.mp4',caption:'Committed replacement caption'}]);
 assert.equal(c.jobs[0].status,'published');
});

test('restart clears transient editing without releasing interrupted delivery',()=>{
 const c=make();c.editing=true;c.jobs[0].status='processing';
 recover(c);assert.equal(Object.hasOwn(c,'editing'),false);
 assert.equal(c.jobs[0].status,'needs_attention');
 assert.equal(c.jobs[1].status,'blocked');
});
