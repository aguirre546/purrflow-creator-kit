import test from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {request} from 'node:http';
import {createServer} from 'node:net';
import {mkdtemp, readFile, writeFile, rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {fileURLToPath, pathToFileURL} from 'node:url';
import {campaign, notSentAcknowledgment, reconcileJob, recover, reschedule, tick} from '../core.mjs';

const root = fileURLToPath(new URL('../', import.meta.url));
const expectedAccountId = 'test-mochi-account';
const make = (selected = ['youtube'], now = 100000) => campaign({
  idea: 'Mochi investigates his empty cardboard snack box',
  platforms: selected,
  scheduledAt: new Date(now + 100000).toISOString()
}, now);
function hold(c, statuses = ['needs_attention']) {
  c.videoPath = 'test-only.mp4';
  c.mediaQuality = {passed: true};
  c.jobs.forEach((job, i) => {job.status = statuses[i] || 'failed'; job.attempts = i + 1;});
  return c;
}
const receipt = (platform = 'youtube') => ({
  platform, accountId: expectedAccountId, status: 'published', visibility: 'public',
  postId: 'already-published', url: platform === 'youtube'
    ? 'https://www.youtube.com/shorts/already-published'
    : 'https://x.com/mochi/status/123'
});
const confirmNotSent = {action: 'confirmed_not_sent', acknowledgment: notSentAcknowledgment};
const options = {now: 900000, expectedAccountId};

test('operator public confirmation requires the configured account and records bounded evidence', () => {
  const c = hold(make());
  const job = c.jobs[0], id = job.id, attempts = job.attempts;
  reconcileJob(c, id, {action: 'published', receipt: {...receipt(), ignoredExtra: 'not audit evidence'}}, options);
  assert.equal(c.state, 'completed');
  assert.equal(job.id, id);
  assert.equal(job.attempts, attempts);
  assert.equal(job.status, 'published');
  assert.equal(job.postId, 'already-published');
  assert.equal(job.reason, null);
  assert.deepEqual(job.reconciliations, [{
    at: new Date(options.now).toISOString(), action: 'published', source: 'operator',
    providerVerified: false, previousStatus: 'needs_attention', receipt: receipt()
  }]);
  assert.match(c.events.at(-1).message, /Provider API verification was not performed/);
});

test('invalid public receipts and missing or mismatched expected accounts leave delivery held', () => {
  const invalid = [
    {receipt: null}, {receipt: {...receipt(), platform: 'x'}},
    {receipt: {...receipt(), accountId: 'different-account'}},
    {receipt: {...receipt(), status: 'processing'}}, {receipt: {...receipt(), visibility: 'private'}},
    {receipt: {...receipt(), postId: ''}}, {receipt: {...receipt(), postId: 123}},
    {receipt: {...receipt(), url: 'https://attacker.example/post/123'}},
    {receipt: {...receipt(), url: 'https://youtube.com.attacker.example/shorts/123'}},
    {receipt: {...receipt(), url: 'https://user:pass@youtube.com/shorts/123'}},
    {receipt: receipt(), expectedAccountId: undefined}, {receipt: receipt(), expectedAccountId: ' '},
    {receipt: receipt(), expectedAccountId: 'another-account'}
  ];
  for (const invalidCase of invalid) {
    const c = hold(make()), before = structuredClone(c);
    const account = Object.hasOwn(invalidCase, 'expectedAccountId') ? invalidCase.expectedAccountId : expectedAccountId;
    assert.throws(() => reconcileJob(c, c.jobs[0].id, {action: 'published', receipt: invalidCase.receipt}, {...options, expectedAccountId: account}));
    assert.deepEqual(c, before);
  }
});

test('no-send confirmation requires the exact acknowledgment and rejects unknown decisions without mutation', () => {
  for (const decision of [undefined, {}, {action: 'retry'}, {action: 'confirmed_not_sent'},
    {...confirmNotSent, acknowledgment: notSentAcknowledgment.toLowerCase()},
    {...confirmNotSent, acknowledgment: notSentAcknowledgment + ' '}]) {
    const c = hold(make()), before = structuredClone(c);
    assert.throws(() => reconcileJob(c, c.jobs[0].id, decision, options));
    assert.deepEqual(c, before);
  }
});

test('confirmed no-send preserves identity and attempts, pauses stale delivery, and needs a future schedule', async () => {
  const c = hold(make());
  const job = c.jobs[0], campaignId = c.id, jobId = job.id, attempts = job.attempts;
  const oldSchedule = c.scheduledAt, oldNextAttempt = job.nextAttemptAt;
  reconcileJob(c, jobId, confirmNotSent, options);
  assert.equal(c.id, campaignId); assert.equal(job.id, jobId); assert.equal(job.attempts, attempts);
  assert.equal(c.scheduledAt, oldSchedule); assert.equal(job.nextAttemptAt, oldNextAttempt);
  assert.equal(job.status, 'paused'); assert.equal(c.paused, true); assert.equal(c.state, 'paused');
  assert.equal(job.reconciliations[0].providerVerified, false);
  let calls = 0;
  const adapters = {youtube: async ({idempotencyKey}) => {calls++; assert.equal(idempotencyKey, jobId); return {postId: 'new-publication'};}};
  await tick(c, adapters, {now: options.now});
  recover(c);
  await tick(c, adapters, {now: options.now + 60000});
  assert.equal(calls, 0); assert.equal(job.attempts, attempts);
  assert.throws(() => reschedule(c, oldSchedule, options.now));
  assert.throws(() => reschedule(c, new Date(options.now + 59999).toISOString(), options.now));
  assert.equal(c.paused, true);
  const future = options.now + 120000;
  reschedule(c, new Date(future).toISOString(), options.now);
  assert.equal(c.paused, false); assert.equal(job.id, jobId); assert.equal(job.attempts, attempts);
  await tick(c, adapters, {now: future - 1}); assert.equal(calls, 0);
  await tick(c, adapters, {now: future}); assert.equal(calls, 1);
  assert.equal(job.status, 'published'); assert.equal(job.attempts, attempts + 1);
});

test('all held destinations need decisions and published destinations never resend', async () => {
  const c = hold(make(['youtube', 'x', 'tiktok']), ['needs_attention', 'failed', 'failed']);
  const [published, x, tiktok] = c.jobs;
  reconcileJob(c, published.id, {action: 'published', receipt: receipt()}, options);
  reconcileJob(c, x.id, confirmNotSent, options);
  assert.equal(c.paused, true); assert.equal(c.state, 'needs_attention');
  assert.throws(() => reschedule(c, new Date(1100000).toISOString(), options.now), /Resolve failed jobs/);
  reconcileJob(c, tiktok.id, confirmNotSent, options);
  assert.equal(c.state, 'paused');
  const future = 1100000, sent = [];
  const adapters = Object.fromEntries(['youtube', 'x', 'tiktok'].map(platform => [platform, async () => {
    sent.push(platform); return {postId: `new-${platform}`};
  }]));
  await tick(c, adapters, {now: future}); assert.deepEqual(sent, []);
  reschedule(c, new Date(future).toISOString(), options.now);
  await tick(c, adapters, {now: future});
  await tick(c, adapters, {now: future + 60000});
  assert.deepEqual(sent.sort(), ['tiktok', 'x']);
  assert.equal(published.postId, 'already-published'); assert.equal(published.attempts, 1);
  assert.equal(c.state, 'completed');
});

test('reconciliation refuses editing, any processing destination, unknown jobs, and terminal or dispatchable states', () => {
  for (const mutation of [c => {c.editing = true;}, c => {c.jobs[1].status = 'processing';}]) {
    const c = hold(make(['youtube', 'x'])); mutation(c); const before = structuredClone(c);
    assert.throws(() => reconcileJob(c, c.jobs[0].id, confirmNotSent, options), /in progress/);
    assert.deepEqual(c, before);
  }
  const c = hold(make()), before = structuredClone(c);
  assert.throws(() => reconcileJob(c, 'unknown-job', confirmNotSent, options), /Unknown publishing job/);
  assert.deepEqual(c, before);
  for (const status of ['published', 'paused', 'blocked', 'queued', 'retry', 'schedule_hold']) {
    const held = hold(make()); held.jobs[0].status = status; const snapshot = structuredClone(held);
    assert.throws(() => reconcileJob(held, held.jobs[0].id, confirmNotSent, options), /Only failed or uncertain/);
    assert.deepEqual(held, snapshot);
  }
});

function isolatedEnv() {
  const env = {...process.env};
  for (const key of Object.keys(env)) if (/^PURRFLOW_/i.test(key)) delete env[key];
  delete env.NODE_OPTIONS;
  return env;
}
async function freePort() {
  const server = createServer();
  await new Promise((resolve, reject) => {server.once('error', reject); server.listen(0, '127.0.0.1', resolve);});
  const {port} = server.address();
  await new Promise(resolve => server.close(resolve));
  return port;
}
async function fixture({campaigns, extraEnv = {}, preload} = {}) {
  const dir = await mkdtemp(path.join(tmpdir(), 'purrflow-reconciliation-'));
  const port = await freePort(), base = `http://127.0.0.1:${port}`;
  let child;
  if (campaigns) await writeFile(path.join(dir, 'campaigns.json'), JSON.stringify(campaigns));
  async function start() {
    let stderr = '';
    child = spawn(process.execPath, [...(preload ? ['--import', pathToFileURL(preload).href] : []), 'server.mjs'], {
      cwd: root, env: {...isolatedEnv(), PORT: String(port), PURRFLOW_DATA: dir, ...extraEnv},
      stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true
    });
    child.stderr.on('data', bytes => {stderr += bytes;});
    await new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(Error(`Startup timed out: ${stderr}`)), 10000);
      const fail = error => {clearTimeout(timer); reject(error);};
      child.once('error', fail);
      child.once('exit', code => fail(Error(`Server exited ${code}: ${stderr}`)));
      child.stdout.once('data', () => {clearTimeout(timer); resolve();});
    });
  }
  async function stop() {
    if (child && child.exitCode === null) await new Promise(resolve => {child.once('exit', resolve); child.kill();});
  }
  async function close() {await stop(); await rm(dir, {recursive: true, force: true});}
  const post = (route, body) => fetch(base + route, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body)});
  const list = async () => (await fetch(base + '/api/campaigns')).json();
  return {dir, base, start, stop, close, post, list};
}
const route = (c, job = c.jobs[0]) => `/api/campaigns/${c.id}/jobs/${job.id}/reconcile`;
async function waitFor(check) {
  const until = Date.now() + 5000;
  while (Date.now() < until) {if (await check()) return; await new Promise(resolve => setTimeout(resolve, 10));}
  throw Error('Timed out waiting for deterministic test barrier');
}

test('HTTP reconciles held deliveries, retains operator evidence across restart, and requires explicit rescheduling', {timeout: 25000}, async () => {
  const c = hold(make(['youtube', 'x'], Date.now() - 200000));
  const [published, unsent] = c.jobs, originalAttempts = c.jobs.map(job => job.attempts);
  const f = await fixture({campaigns: [c], extraEnv: {PURRFLOW_YOUTUBE_ACCOUNT_ID: expectedAccountId}});
  try {
    await f.start();
    const status = await (await fetch(f.base + '/api/status')).json();
    assert.equal(status.reconciliation.expectedAccounts.youtube, true);
    assert.equal(status.reconciliation.expectedAccounts.x, false);
    assert.equal(status.reconciliation.notSentAcknowledgment, notSentAcknowledgment);
    assert.equal((await f.post(route(c), {action: 'published', receipt: {...receipt(), accountId: 'wrong'}})).status, 400);
    assert.equal((await f.post(route(c, unsent), {action: 'published', receipt: receipt('x')})).status, 400);
    assert.equal((await f.post(route(c, unsent), {action: 'confirmed_not_sent'})).status, 400);
    assert((await f.list())[0].jobs.every(job => !job.reconciliations));
    const confirmed = await f.post(route(c), {action: 'published', receipt: receipt()});
    assert.equal(confirmed.status, 200);
    assert.deepEqual(await confirmed.json(), {ok: true, jobId: published.id, status: 'published', campaignState: 'needs_attention', source: 'operator', providerVerified: false, nextStep: 'Operator confirmation saved. Review remaining destination states.'});
    assert.equal((await f.post(route(c, unsent), confirmNotSent)).status, 200);
    assert.equal((await f.post(route(c), {action: 'published', receipt: receipt()})).status, 400);
    await f.post('/api/run', {});
    await f.stop(); await f.start();
    const [restored] = await f.list();
    assert.equal(restored.paused, true); assert.equal(restored.state, 'paused');
    assert.deepEqual(restored.jobs.map(job => job.id), c.jobs.map(job => job.id));
    assert.deepEqual(restored.jobs.map(job => job.attempts), originalAttempts);
    assert.deepEqual(restored.jobs.map(job => job.status), ['published', 'paused']);
    assert.equal(restored.jobs[0].postId, 'already-published');
    assert(restored.jobs.every(job => job.reconciliations.length === 1 && job.reconciliations[0].providerVerified === false));
    assert.equal((await f.post(`/api/campaigns/${c.id}/schedule`, {scheduledAt: c.scheduledAt})).status, 400);
    const future = new Date(Date.now() + 3600000).toISOString();
    assert.equal((await f.post(`/api/campaigns/${c.id}/schedule`, {scheduledAt: future})).status, 200);
    const [scheduled] = await f.list();
    assert.equal(scheduled.paused, false); assert.equal(scheduled.jobs[0].status, 'published');
    assert.equal(scheduled.jobs[1].nextAttemptAt, Date.parse(future));
    assert.deepEqual(scheduled.jobs.map(job => job.attempts), originalAttempts);
    assert.equal((await f.post(route({...c, id: '00000000-0000-0000-0000-000000000000'}), confirmNotSent)).status, 404);
    assert.equal((await f.post(route(c, {id: '00000000-0000-0000-0000-000000000000'}), confirmNotSent)).status, 404);
    const persisted = JSON.parse(await readFile(path.join(f.dir, 'campaigns.json'), 'utf8'));
    assert.equal(persisted[0].jobs[0].reconciliations[0].receipt.accountId, expectedAccountId);
  } finally {await f.close();}
});

test('HTTP refuses reconciliation while editing, including when editing starts during request-body receipt', {timeout: 20000}, async () => {
  const c = hold(make(['youtube', 'x'], Date.now()));
  // A failed destination is editable; a second failed job is the reconciliation target.
  c.jobs.forEach(job => {job.status = 'failed';});
  const f = await fixture({campaigns: [c]});
  let edit, delayed;
  try {
    await f.start();
    const delayedResponse = new Promise((resolve, reject) => {
      delayed = request(f.base + route(c, c.jobs[1]), {method: 'POST', headers: {'Content-Type': 'application/json'}}, response => {
        response.resume(); response.once('end', () => resolve(response.statusCode));
      });
      delayed.once('error', reject);
      delayed.write('{"action":"confirmed_not_sent",');
    });
    delayedResponse.catch(() => {});
    await new Promise(resolve => setTimeout(resolve, 30));
    const editResponse = new Promise((resolve, reject) => {
      edit = request(f.base + `/api/campaigns/${c.id}/drafts`, {method: 'POST', headers: {'Content-Type': 'application/json'}}, response => {
        response.resume(); response.once('end', () => resolve(response.statusCode));
      });
      edit.once('error', reject); edit.write('{');
    });
    editResponse.catch(() => {});
    await waitFor(async () => (await f.list())[0].editing === true);
    assert.equal((await f.post(route(c, c.jobs[1]), confirmNotSent)).status, 409);
    delayed.end(`"acknowledgment":${JSON.stringify(notSentAcknowledgment)}}`);
    assert.equal(await delayedResponse, 409);
    edit.end(JSON.stringify(c.drafts).slice(1));
    assert.equal(await editResponse, 200);
    const [unchanged] = await f.list();
    assert(unchanged.jobs.every(job => job.status === 'failed' && !job.reconciliations));
  } finally {edit?.destroy(); delayed?.destroy(); await f.close();}
});

test('HTTP scheduler busy guard holds reconciliation while a local fake provider is awaiting a receipt', {timeout: 25000}, async () => {
  const scratch = await mkdtemp(path.join(tmpdir(), 'purrflow-provider-stub-'));
  const started = path.join(scratch, 'started'), released = path.join(scratch, 'release');
  const preload = path.join(scratch, 'provider-stub.mjs');
  // This child-only stub fails closed for every URL except one fake publisher URL.
  // No network request or real provider is used, and no credentials are inherited.
  await writeFile(preload, `import fs from 'node:fs/promises';
globalThis.fetch = async (url) => {
 if (url !== 'https://publisher.invalid/test-only') throw Error('Unexpected provider URL in isolated test');
 await fs.writeFile(${JSON.stringify(started)}, 'started');
 while (true) {try {await fs.access(${JSON.stringify(released)}); break;} catch {await new Promise(r => setTimeout(r, 10));}}
 return new Response(JSON.stringify(${JSON.stringify(receipt())}), {status: 200, headers: {'Content-Type': 'application/json'}});
};`);
  const due = make(['youtube'], Date.now() - 100000);
  due.videoPath = path.join(scratch, 'fake.mp4'); due.mediaQuality = {passed: true}; due.jobs[0].status = 'queued';
  await writeFile(due.videoPath, 'fake media read by the fake publisher only');
  const held = hold(make(['x'], Date.now()));
  const f = await fixture({campaigns: [due, held], preload, extraEnv: {
    PURRFLOW_YOUTUBE_WEBHOOK: 'https://publisher.invalid/test-only',
    PURRFLOW_YOUTUBE_ACCOUNT_ID: expectedAccountId, PURRFLOW_WEBHOOK_TOKEN: 'test-only-no-real-credential'
  }});
  let running;
  try {
    await f.start();
    running = f.post('/api/run', {});
    running.catch(() => {});
    await waitFor(async () => {try {await readFile(started); return true;} catch {return false;}});
    const blocked = await f.post(route(held), confirmNotSent);
    assert.equal(blocked.status, 409); assert.match((await blocked.json()).error, /Scheduler busy/);
    assert.equal((await f.list())[1].jobs[0].status, 'needs_attention');
    await writeFile(released, 'release');
    assert.equal((await running).status, 200);
    assert.equal((await f.post(route(held), confirmNotSent)).status, 200);
    const saved = await f.list();
    assert.equal(saved[0].jobs[0].status, 'published');
    assert.equal(saved[0].jobs[0].attempts, 1);
    assert.equal(saved[1].jobs[0].status, 'paused');
  } finally {
    await writeFile(released, 'release');
    await running?.catch(() => {});
    await f.close(); await rm(scratch, {recursive: true, force: true});
  }
});
