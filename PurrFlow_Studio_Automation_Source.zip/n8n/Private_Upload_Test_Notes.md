# Private YouTube upload test

Prepared November 12, 2026. This export has **not been run against Google**. Importing it does not prove that quotas or permissions allow an upload. It is inactive by default. It contains a credential reference, not tokens or secrets.

## Test procedure

1. Import `PurrFlow_Private_YouTube_Upload_Test.json` into a **new** workflow. Leave unpublished/inactive. Confirm the selected saved credential is the intended YouTube account (`SELECT_YOUR_YOUTUBE_CREDENTIAL`).
2. First rerun the separate read-only channel verification workflow. Stop if Google reports quota, permission, or identity errors.
3. Execute the upload workflow in **test mode** and open the Form Trigger's test form. Do not share the test URL or activate its unauthenticated production form.
4. Supply one original MP4, maximum 20 MiB, its title, and `UPLOAD PRIVATE`. Submitting the test form authorizes a single real private upload. Do not submit repeatedly.
5. Verify the final receipt contains the video ID, expected channel ID, and `private` visibility. Check processing in YouTube Studio. API acceptance is separate from completed video processing.

The workflow requires exactly the expected channel `UCMbk56GXDq-THOSjZf1HUZg`, sends `privacyStatus: private` and `containsSyntheticMedia: true`, and will not use generic HTTP retries. Its synthetic-media flag declares the AI origin; the content's audience designation still needs the channel owner's appropriate setting in Studio.

## Limits and failure recovery

This uses Google's resumable session protocol but uploads the small sample as one PUT. It does **not** automatically resume partial uploads. After a timeout, error, or missing receipt, inspect YouTube Studio and the saved execution's session before retrying; a repeated form submission may create a duplicate. Do not share execution data containing a resumable upload URL. There is no durable cross-execution deduplication or seven-day scheduler here.

No paid generation API is configured. YouTube requests consume API quota; this workflow does not purchase quota or bypass limits. A `403 quotaExceeded` blocks the request normally. Other social publishers remain separate work.

## Local checks

Run `node --test outputs/PurrFlow_Studio/n8n/private-upload.test.mjs` from the workspace. These mock tests cover input rejection, identity guard, credential destination URL restriction, private receipt validation, and inactive/no-retry defaults. They do not execute n8n's runtime or real OAuth requests. Confirm import and Form/HTTP node behavior against the deployed n8n version before using it.

## Official implementation references

- [n8n Form Trigger source](https://github.com/n8n-io/n8n/blob/master/packages/nodes-base/nodes/Form/v2/FormTriggerV2.node.ts) and [Form field descriptions](https://github.com/n8n-io/n8n/blob/master/packages/nodes-base/nodes/Form/common.descriptions.ts): version 2.2 form fields and file configuration.
- [n8n HTTP Request parameter source](https://github.com/n8n-io/n8n/blob/master/packages/nodes-base/nodes/HttpRequest/V3/Description.ts): predefined credentials, binary body, full response and response formats.
- [Google resumable upload protocol](https://developers.google.com/youtube/v3/guides/using_resumable_upload_protocol): session POST, Location header, binary PUT and interrupted-upload handling.
- [Google video resource](https://developers.google.com/youtube/v3/docs/videos): status privacy and synthetic-media properties.

The deployed n8n version may differ from upstream master. Current-source verification is a schema cross-check, not an execution result.
