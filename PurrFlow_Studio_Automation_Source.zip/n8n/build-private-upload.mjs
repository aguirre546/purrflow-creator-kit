import fs from 'node:fs/promises';
export const expectedChannel='UCMbk56GXDq-THOSjZf1HUZg';
export const validateCode=`const item=$input.first();
if(item.json.Confirmation!=='UPLOAD PRIVATE')throw new Error('Type UPLOAD PRIVATE to authorize this test.');
const keys=Object.keys(item.binary||{});if(keys.length!==1)throw new Error('Submit exactly one MP4.');
const key=keys[0], file=item.binary[key];
if(!/\\.mp4$/i.test(file.fileName||''))throw new Error('MP4 filename required.');
const buffer=await this.helpers.getBinaryDataBuffer(0,key);
if(buffer.length<12||buffer.length>20*1024*1024||buffer.toString('ascii',4,8)!=='ftyp')throw new Error('MP4 header invalid or file exceeds 20 MiB.');
const title=String(item.json.Title||'').trim();if(!title||title.length>100||/[<>]/.test(title))throw new Error('Title must be 1–100 characters without angle brackets.');
return [{json:{title,byteLength:buffer.length,expectedChannel:'${expectedChannel}',metadata:{snippet:{title,description:'Original AI-generated Mochi Mischief story. Fictional characters and scenes. Private automation test.',categoryId:'15',tags:['Mochi Mischief','AI cat story']},status:{privacyStatus:'private',containsSyntheticMedia:true}}},binary:{video:{...file,mimeType:'video/mp4'}},pairedItem:{item:0}}];`;
export const guardCode=`const items=$input.first().json.items||[];const expected='${expectedChannel}';
// Require exactly the intended authorized channel, avoiding an ambiguous multi-channel upload.
if(items.length!==1||items[0].id!==expected)throw new Error('Connected channel does not uniquely match Mochi Mischief. Upload blocked.');
const original=$('Validate private submission').first();return [{json:{...original.json,verifiedChannelId:expected},binary:original.binary,pairedItem:{item:0}}];`;
export const restoreCode=`const response=$input.first().json;
const location=response.headers?.location||response.headers?.Location;
// Restrict the credential-bearing PUT to the exact Google upload host and path.
if(typeof location!=='string'||!/^https:\\/\\/www\\.googleapis\\.com\\/upload\\/youtube\\/v3\\/videos\\?/.test(location))throw new Error('Missing or unexpected resumable URL. Upload stopped; inspect session response.');
const original=$('Validate private submission').first();return [{json:{uploadUrl:location,byteLength:original.json.byteLength},binary:original.binary,pairedItem:{item:0}}];`;
export const receiptCode=`const video=$input.first().json;
if(!video.id||video.snippet?.channelId!=='${expectedChannel}'||video.status?.privacyStatus!=='private')throw new Error('Upload response did not confirm the expected private video. Inspect YouTube Studio before retrying.');
return [{json:{confirmed:true,videoId:video.id,url:'https://www.youtube.com/watch?v='+video.id,channelId:video.snippet.channelId,privacyStatus:video.status.privacyStatus,syntheticMedia:video.status.containsSyntheticMedia??null,checkedAt:new Date().toISOString(),note:'API acceptance confirmed; video processing may still be pending.'}}];`;
const credentials={youTubeOAuth2Api:{id:'SELECT_YOUR_YOUTUBE_CREDENTIAL',name:'YouTube account'}};
const auth={authentication:'predefinedCredentialType',nodeCredentialType:'youTubeOAuth2Api'};
const http=(id,name,parameters,x)=>({id,name,type:'n8n-nodes-base.httpRequest',typeVersion:4.2,position:[x,300],parameters:{...auth,...parameters},credentials,retryOnFail:false});
const code=(id,name,jsCode,x)=>({id,name,type:'n8n-nodes-base.code',typeVersion:2,position:[x,300],parameters:{jsCode}});
export const workflow={name:'PurrFlow Studio — Private YouTube Upload Test',active:false,nodes:[
{id:'form',name:'Submit one private test video',type:'n8n-nodes-base.formTrigger',typeVersion:2.2,position:[0,300],webhookId:'39cd15a3-f5fd-4eb5-a106-aac8eb3a8fb4',parameters:{formTitle:'Mochi Mischief — Private upload test',formDescription:'Test mode only. Upload one original MP4. This will create a PRIVATE video on the verified Mochi channel. Do not resubmit after an ambiguous failure until checking YouTube Studio.',formFields:{values:[{fieldLabel:'Video',fieldType:'file',multipleFiles:false,acceptFileTypes:'.mp4',requiredField:true},{fieldLabel:'Title',fieldType:'text',defaultValue:'Mochi investigates the mysterious box | Private test',requiredField:true},{fieldLabel:'Confirmation',fieldType:'text',placeholder:'UPLOAD PRIVATE',requiredField:true}]},responseMode:'lastNode',options:{buttonLabel:'Upload privately',respondWithOptions:{values:{respondWith:'text',formSubmittedText:'Workflow finished. Open the final n8n node to verify the video ID and Private status.'}}}}},
code('validate','Validate private submission',validateCode,240),
http('identity','Read authorized YouTube channel',{url:'https://www.googleapis.com/youtube/v3/channels?part=snippet&mine=true',options:{timeout:30000}},480),
code('guard','Guard Mochi channel identity',guardCode,720),
http('init','Initiate private resumable upload',{method:'POST',url:'https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status',sendHeaders:true,headerParameters:{parameters:[{name:'X-Upload-Content-Type',value:'video/mp4'},{name:'X-Upload-Content-Length',value:'={{ $json.byteLength }}'}]},sendBody:true,specifyBody:'json',jsonBody:'={{ JSON.stringify($json.metadata) }}',options:{timeout:30000,response:{response:{fullResponse:true,responseFormat:'text'}},redirect:{redirect:{followRedirects:false}}}},960),
code('restore','Validate session and restore binary',restoreCode,1200),
http('upload','Upload MP4 once',{method:'PUT',url:'={{ $json.uploadUrl }}',sendHeaders:true,headerParameters:{parameters:[{name:'Content-Type',value:'video/mp4'},{name:'Content-Length',value:'={{ $json.byteLength }}'}]},sendBody:true,contentType:'binaryData',inputDataFieldName:'video',options:{timeout:120000,redirect:{redirect:{followRedirects:false}},response:{response:{responseFormat:'json'}}}},1440),
code('receipt','Confirm private upload receipt',receiptCode,1680)
],connections:{},settings:{executionOrder:'v1',timezone:'Asia/Manila'},pinData:{},tags:[]};
for(let i=0;i<workflow.nodes.length-1;i++)workflow.connections[workflow.nodes[i].name]={main:[[{node:workflow.nodes[i+1].name,type:'main',index:0}]]};
if(process.argv[1]&&import.meta.url.endsWith(process.argv[1].replaceAll('\\','/').split('/').pop()))await fs.writeFile(new URL('./PurrFlow_Private_YouTube_Upload_Test.json',import.meta.url),JSON.stringify(workflow,null,2));
