# Source preservation update - November 14, 2026

This is the earlier, unfinished PurrFlow Studio automation prototype, published as a separate archive in aguirre546/purrflow-creator-kit. The access/connection statements below are historical November 12 notes and require a fresh check. Configure your own authorized endpoints and n8n credentials. No OAuth secrets, runtime campaigns, videos or locks are included. Local tests do not prove live publishing.

# PurrFlow Studio

Local Mochi Mischief campaign planner and publishing queue. Team Technology Mafia, Victor Aguirre. Current repair evidence: 31 passing local tests, real caption rendering, and updated three-minute recorded walkthrough. **Live generation and social publishers are not connected.** No seven-day unattended result exists.

## Run locally

Requires Node 22+ and a trusted FFmpeg with libass/libx264 for caption rendering. Set PURRFLOW_FFMPEG, then run `node server.mjs` from this directory. Default address is http://127.0.0.1:4318. `node --test` runs isolated fixtures; the real-media tests need FFmpeg. `.env.example` documents optional authorized endpoints; use `node --env-file=.env server.mjs` after configuring your own secret file. Never commit `.env` or runtime data.

## Working behavior

- One MP4 and common future release time across selected destinations, with distinct editable copy.
- Pause and reschedule controls. First attempts over two minutes late hold rather than automatically releasing an old test.
- Campaign editing locks block publication during upload, validation, caption rendering and copy edits.
- MP4 full decode gate: 15 seconds (+/-0.5), 720 x 1280. Generic narrative captions are automatically burned into new uploads. Check Already has captions when supplying a finished captioned clip. These overlays are not speech transcripts; automatic speech transcription is not implemented.
- Concurrent dispatch, persisted job state, uncertain delivery hold and interrupted-operation reconciliation. Published destinations are not resent. Failed or ambiguous jobs cannot be blindly reset through rescheduling.
- Conservative per-platform copy/tag validation and strict publication receipts.
- Runtime credit-only policy and exact model/duration/resolution/count configuration checks. Generation itself is not connected.
- Local exception outbox, deduplication and optional bounded-retry HTTPS delivery. Actual notification recipient is not connected.
- Single-host writer lock, serialized startup, atomic state replacement and previous-state backup. Not a distributed database or automatic disaster restoration system.

## Publisher contract

A configured URL is not proof of a live connection. Every publisher requires HTTPS, nonempty PURRFLOW_WEBHOOK_TOKEN and the matching PURRFLOW_<PLATFORM>_ACCOUNT_ID. Redirects and embedded URL credentials are refused. Payload contains campaign/job IDs, idempotency key header, shared MP4 base64, platform metadata and expected account ID. The authorized external publisher must enforce its own durable deduplication, platform authorization, AI/audience/visibility fields and processing checks.

Successful public receipt must include `platform`, exact `accountId`, `status: published`, `visibility: public`, `postId`, and an HTTPS `url`. Queued/processing/private receipts do not mean public success. Network/ambiguous errors hold for reconciliation. A working service implementing this contract is still required; this repository does not pretend the generic transport is a native Facebook/TikTok/X adapter.

## Access and uptime limits

Facebook/Instagram profiles were linked, but API app/publishing access is incomplete. Meta developer registration awaits acceptance of the displayed terms. YouTube OAuth was saved, but the latest live API check returned quotaExceeded; exact API channel identity and single Private upload need verification. X API credits/access are unverified and new purchases are forbidden. TikTok requires a permitted integration. Flow browser auto-credit approval is not unattended generation or automatic account switching.

The application intentionally binds only to loopback and rejects unexpected Hosts. Do not expose this server directly: public authentication, compatible cloud storage/runtime, and security review are unfinished. Node/filesystem/FFmpeg cannot simply be uploaded as a static Cloudflare Pages site. Media storage retention and a true always-on deployment remain open.

No credit ledger, recurring 3-5-video production worker, speech transcription, audience analytics optimizer, completed overnight/seven-day test, or judge-accessible repository/deployment exists. Provider approvals and existing-credit limits may constrain the requested final system.

## Demo and evidence

The updated 180-second walkthrough uses the real captioned 15-second Omni sample and current controls. It is assembled recorded evidence with narration, not an unattended end-to-end recording. Full decode passed. See the parent output directory's PurrFlow_Repair_Result_2026-11-12.md for exact repaired/remaining audit items.

## n8n

The private upload test export and content-pack validation export are under n8n/. The Private test is inactive/unpublished and must not be made an unauthenticated production uploader. Review Private_Upload_Test_Notes.md. Mock tests validate guards, not live Google authorization. Never share resumable upload URLs or OAuth execution secrets.

## Budget and submission

Existing credits only. No purchases, paid API billing or top-ups. Do not submit the competition entry without a separate explicit instruction.
