# Source preservation update - November 14, 2026

This is the earlier, unfinished PurrFlow Studio automation prototype, published as a separate archive in aguirre546/purrflow-creator-kit. The access/connection statements below are historical November 12 notes and require a fresh check. Configure your own authorized endpoints and n8n credentials. No OAuth secrets, runtime campaigns, videos or locks are included. Local tests do not prove live publishing.

# PurrFlow Studio

Local Mochi Mischief campaign planner and publishing queue. Team Technology Mafia, Victor Aguirre. Updated November 20, 2026, with conservative delivery recovery, corrupt-video rejection, a read-only readiness command, and a separate private YouTube test CLI. **Live generation and social publishers are not connected.** No seven-day unattended result exists.

## Run locally

Requires Node 22+ and a trusted FFmpeg with libass/libx264 for caption rendering. Set PURRFLOW_FFMPEG, then run `npm start` from this directory. Default address is http://127.0.0.1:4318. `npm test` runs isolated fixtures and strips production PurrFlow configuration from test subprocesses; only the FFmpeg path is inherited. Real-media tests require FFmpeg. `.env.example` documents optional authorized endpoints; use `node --env-file=.env server.mjs` after configuring your own secret file. Never commit `.env` or runtime data.

`npm run doctor` checks local configuration without network requests or credential output. Exit code 2 means unattended readiness is not established. A configured endpoint or token is not a verified service connection.

The private YouTube uploader is documented in [integrations/README.md](integrations/README.md). It requires an authorized token supplied securely through the process environment and an explicit audience choice. It can only upload privately to the expected Mochi channel. It is not connected to this web scheduler and has not completed a live upload.

## Working behavior

- One MP4 and common future release time across selected destinations, with distinct editable copy.
- Pause and reschedule controls. First attempts over two minutes late hold rather than automatically releasing an old test.
- Campaign editing locks block publication during upload, validation, caption rendering and copy edits.
- MP4 full decode gate: 15 seconds (+/-0.5), 720 x 1280. Generic narrative captions are automatically burned into new uploads. Check Already has captions when supplying a finished captioned clip. These overlays are not speech transcripts; automatic speech transcription is not implemented.
- Concurrent dispatch, persisted job state, uncertain delivery hold and interrupted-operation reconciliation. Published destinations are not resent. Failed or ambiguous jobs cannot be blindly reset through rescheduling. Unknown errors hold for review; only an adapter's explicit retryable failure before dispatch may retry.
- Held-job review controls record an operator's checked public receipt, or an exact acknowledgment that no post was sent. A no-post decision pauses the campaign and requires a new future schedule. IDs, attempt counts, and decision history are retained. These are operator confirmations, not fresh provider API verification.
- Conservative per-platform copy/tag validation and strict publication receipts.
- Runtime credit-only policy and exact model/duration/resolution/count configuration checks. Generation itself is not connected.
- Local exception outbox, deduplication and optional bounded-retry HTTPS delivery. Actual notification recipient is not connected.
- Single-host writer lock, serialized startup, atomic state replacement and previous-state backup. Not a distributed database or automatic disaster restoration system.

## Publisher contract

A configured URL is not proof of a live connection. Every publisher requires HTTPS, nonempty PURRFLOW_WEBHOOK_TOKEN and the matching PURRFLOW_<PLATFORM>_ACCOUNT_ID. Redirects and embedded URL credentials are refused. Payload contains campaign/job IDs, idempotency key header, shared MP4 base64, platform metadata and expected account ID. The authorized external publisher must enforce its own durable deduplication, platform authorization, AI/audience/visibility fields and processing checks.

Successful public receipt must include `platform`, exact `accountId`, `status: published`, `visibility: public`, `postId`, and an HTTPS `url`. Queued/processing/private receipts do not mean public success. Network/ambiguous errors hold for reconciliation. A working service implementing this contract is still required; this repository does not pretend the generic transport is a native Facebook/TikTok/X adapter.

## Access and uptime limits

Facebook/Instagram profiles were historically linked, but API app/publishing access remains unverified. On November 20 the signed-in n8n Cloud instance refused a read-only YouTube channel workflow because its trial had ended; no Google API request or upload was verified. Earlier quota and OAuth popup errors are historical. X access and existing credits remain unverified. TikTok requires an eligible integration; its current Direct Post guidelines exclude utilities limited to accounts managed by the developer or their team. Flow browser credit approval is not unattended generation or automatic account switching. No new terms, permissions, trials, upgrades or credit purchases are authorized by this source release.

The application intentionally binds only to loopback and rejects unexpected Hosts. Do not expose this server directly: public authentication, compatible cloud storage/runtime, and security review are unfinished. Node/filesystem/FFmpeg cannot simply be uploaded as a static Cloudflare Pages site. Media storage retention and a true always-on deployment remain open.

No credit ledger, recurring 3-5-new-video production worker, speech transcription, audience analytics optimizer, or completed overnight/seven-day test exists. The Creator Kit is separately published at https://github.com/aguirre546/purrflow-creator-kit and https://purrflow-creator-kit.studio-builder.workers.dev/ . Those publications do not host this Node/FFmpeg worker. Provider approvals and existing-credit limits constrain the requested final system.

## Demo and evidence

The updated 180-second walkthrough uses the real captioned 15-second Omni sample and current controls. It is assembled recorded evidence with narration, not an unattended end-to-end recording. Full decode passed. See the parent output directory's PurrFlow_Repair_Result_2026-11-12.md for exact repaired/remaining audit items.

## n8n

The private upload test export and content-pack validation export are under n8n/. The Private test is inactive/unpublished and must not be made an unauthenticated production uploader. Review Private_Upload_Test_Notes.md. Mock tests validate guards, not live Google authorization. Never share resumable upload URLs or OAuth execution secrets.

## Current external gates

- n8n Cloud: trial expired, verified November 20. The local Node worker and test CLI do not depend on an active cloud trial. Migrating credentials or changing OAuth access requires a separate reviewed setup.
- Generation: the connected Runway workspace exposed no video models; Google Omni API video generation is a paid-tier capability. No account balance or prepaid API entitlement has been verified for an unattended route. Keep generation disconnected under the no-new-charges rule.
- Meta: authorized professional/Page destinations, provider permissions, processing receipts, and suitable private media hosting still need verification.
- Hosting/alerts: secure persistent processing, a real exception recipient, and endurance observation are still required.

Provider references reviewed November 20: [TikTok content-sharing rules](https://developers.tiktok.com/docs/en/content-sharing-guidelines), [Google API pricing](https://aistudio.google.com/docs/pricing#gemini-omni-1.2-flash), [n8n trial limits](https://docs.n8n.io/deploy/use-n8n-cloud/start-your-free-trial.md), [X API pricing](https://docs.x.com/x-api/getting-started/pricing), and [Instagram publishing](https://developers.facebook.com/documentation/instagram-platform/content-publishing).

## Budget and submission

Existing credits only. No purchases, paid API billing or top-ups. Do not submit the competition entry without a separate explicit instruction.
