import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {mkdtemp, writeFile, copyFile, rm, stat} from 'node:fs/promises';
import {constants} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';

const run = promisify(execFile);
const MAX_SECONDS = 15.5;

// These are narrative overlays, never a claimed transcript of generated audio.
// Deliberately avoid inventing actions, props, dialogue, or outcomes from an idea.
export function narrativeCues(idea) {
  if (typeof idea !== 'string' || !idea.trim()) throw new Error('A story idea is required.');
  return [
    {start: 0, end: 4, text: 'A little moment with Mochi'},
    {start: 4, end: 9, text: 'Original AI cat story'},
    {start: 10, end: 15, text: 'What would your cat do?'}
  ];
}

function validateCues(cues) {
  if (!Array.isArray(cues) || !cues.length || cues.length > 20) throw new Error('Provide 1–20 caption cues.');
  let previousEnd = 0;
  return cues.map((cue) => {
    if (!cue || typeof cue !== 'object' || !Number.isFinite(cue.start) || !Number.isFinite(cue.end) || cue.start < previousEnd || cue.start < 0 || cue.end <= cue.start || cue.end > MAX_SECONDS || cue.end - cue.start < 0.1) {
      throw new Error('Caption times must be ordered, non-overlapping, and within 0–15.5 seconds.');
    }
    if (typeof cue.text !== 'string' || !cue.text.trim() || cue.text.length > 160 || /[\u0000-\u0008\u000b-\u001f\u007f]/u.test(cue.text)) throw new Error('Caption text must contain 1–160 printable characters.');
    const lines = cue.text.trim().split(/\r?\n/);
    if (lines.length > 3 || lines.some(line => line.length > 52)) throw new Error('Captions must fit at most three lines of 52 characters.');
    previousEnd = cue.end;
    return {...cue, text: cue.text.trim()};
  });
}

function timestamp(seconds) {
  const centiseconds = Math.round(seconds * 100);
  return `0:00:${String(Math.floor(centiseconds / 100)).padStart(2, '0')}.${String(centiseconds % 100).padStart(2, '0')}`;
}

function assText(text) {
  // Escape ASS overrides and line-break escapes supplied as literal user text.
  return text.replace(/\\/g, '\\\\').replace(/\{/g, '\\{').replace(/\}/g, '\\}').replace(/\r?\n/g, '\\N');
}

export async function renderCaptions({input, output, cues, ffmpeg} = {}) {
  const checked = validateCues(cues);
  if (typeof ffmpeg !== 'string' || !ffmpeg.trim()) throw new Error('Configure a trusted FFmpeg executable for captions.');
  if (typeof input !== 'string' || typeof output !== 'string' || !path.isAbsolute(input) || !path.isAbsolute(output) || path.resolve(input) === path.resolve(output) || path.extname(output).toLowerCase() !== '.mp4') throw new Error('Use distinct absolute input and MP4 output paths.');
  const source = await stat(input);
  if (!source.isFile()) throw new Error('Caption input must be a video file.');
  const working = await mkdtemp(path.join(tmpdir(), 'purrflow-captions-'));
  const ass = `[Script Info]\nScriptType: v4.00+\nPlayResX: 720\nPlayResY: 1280\nWrapStyle: 0\n\n[V4+ Styles]\nFormat: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\nStyle: Default,Segoe UI,40,&H00FFFFFF,&H000000FF,&H00151515,&H70000000,-1,0,0,0,100,100,0,0,1,3,1,8,52,52,180,1\n\n[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n` + checked.map(cue => `Dialogue: 0,${timestamp(cue.start)},${timestamp(cue.end)},Default,,0,0,0,,${assText(cue.text)}\n`).join('');
  try {
    await writeFile(path.join(working, 'captions.ass'), ass, 'utf8');
    // Fixed relative filter filename avoids FFmpeg filter-path interpolation.
    // execFile never invokes a command shell. Audio is copied without transcription.
    await run(ffmpeg, ['-hide_banner', '-nostdin', '-xerror', '-err_detect', 'explode', '-y', '-i', input, '-map', '0:v:0', '-map', '0:a?', '-vf', 'ass=captions.ass', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '19', '-pix_fmt', 'yuv420p', '-c:a', 'copy', '-movflags', '+faststart', 'rendered.mp4'], {cwd: working, timeout: 120000, maxBuffer: 2 * 1024 * 1024, windowsHide: true});
    await run(ffmpeg, ['-hide_banner', '-nostdin', '-xerror', '-err_detect', 'explode', '-i', path.join(working, 'rendered.mp4'), '-map', '0:v:0', '-an', '-f', 'null', '-'], {timeout: 60000, maxBuffer: 1024 * 1024, windowsHide: true});
    // Do not overwrite an original or an existing deliverable, including races.
    await copyFile(path.join(working, 'rendered.mp4'), output, constants.COPYFILE_EXCL);
    return {output, cues: checked, kind: 'narrative', burnedIn: true, decoded: true};
  } finally {
    await rm(working, {recursive: true, force: true});
  }
}
